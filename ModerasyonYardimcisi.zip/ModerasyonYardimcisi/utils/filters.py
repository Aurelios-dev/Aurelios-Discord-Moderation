import re
import asyncio
from datetime import datetime, timedelta
from typing import List, Tuple

class WordFilter:
    """Kelime filtresi sınıfı"""
    
    def __init__(self, bot):
        self.bot = bot
        self._word_cache = {}  # Sunucu ID -> yasaklı kelimeler cache
        self._cache_time = {}  # Cache zamanları
        self.cache_duration = 300  # 5 dakika cache
    
    async def get_banned_words(self, guild_id: int) -> List[Tuple[str, int]]:
        """Sunucunun yasaklı kelimelerini getirir (cache ile)"""
        current_time = datetime.now()
        
        # Cache kontrolü
        if (guild_id in self._word_cache and 
            guild_id in self._cache_time and
            (current_time - self._cache_time[guild_id]).seconds < self.cache_duration):
            return self._word_cache[guild_id]
        
        # Veritabanından getir
        try:
            words = await self.bot.db.get_banned_words(guild_id)
            self._word_cache[guild_id] = words
            self._cache_time[guild_id] = current_time
            return words
        except:
            return []
    
    def clear_cache(self, guild_id: int):
        """Belirli sunucunun cache'ini temizler"""
        if guild_id in self._word_cache:
            del self._word_cache[guild_id]
        if guild_id in self._cache_time:
            del self._cache_time[guild_id]
    
    async def check_message(self, message) -> Tuple[bool, str, int]:
        """
        Mesajı kontrol eder
        Returns: (yasaklı_kelime_var_mı, bulunan_kelime, şiddet_seviyesi)
        """
        if not message.guild:
            return False, "", 0
        
        # Bot mesajları kontrol edilmez
        if message.author.bot:
            return False, "", 0
        
        # Moderatör yetkileri varsa kontrol edilmez
        if message.author.guild_permissions.manage_messages:
            return False, "", 0
        
        # Sunucu ayarlarını kontrol et
        try:
            settings = await self.bot.db.get_guild_settings(message.guild.id)
            if not settings or not settings.get('word_filter_enabled', 1):
                return False, "", 0
        except:
            pass
        
        # Yasaklı kelimeleri al
        banned_words = await self.get_banned_words(message.guild.id)
        if not banned_words:
            return False, "", 0
        
        # Mesaj içeriğini küçük harfe çevir ve temizle
        content = message.content.lower()
        
        # Özel karakterleri temizle (spam koruması için)
        content = re.sub(r'[^\w\s]', '', content)
        content = re.sub(r'\s+', ' ', content).strip()
        
        # Her yasaklı kelimeyi kontrol et
        for word, severity in banned_words:
            word = word.lower().strip()
            
            # Tam kelime eşleşmesi
            if re.search(r'\b' + re.escape(word) + r'\b', content):
                return True, word, severity
            
            # Kısmi eşleşme (karakter aralarında boşluk/özel karakter)
            spaced_word = re.sub(r'(.)', r'\1[\s\W]*', word)
            if re.search(spaced_word, content):
                return True, word, severity
        
        return False, "", 0

class SpamProtection:
    """Spam koruması sınıfı"""
    
    def __init__(self, bot):
        self.bot = bot
        self.message_history = {}  # user_id -> [message_times]
        self.spam_thresholds = {
            'messages_per_minute': 10,  # Dakikada maksimum mesaj
            'duplicate_threshold': 3,   # Aynı mesajdan kaç tane
            'caps_threshold': 0.7,      # Büyük harf oranı
            'mention_threshold': 5      # Maksimum mention sayısı
        }
    
    async def check_spam(self, message) -> Tuple[bool, str]:
        """
        Spam kontrolü yapar
        Returns: (spam_var_mı, spam_türü)
        """
        if not message.guild:
            return False, ""
        
        # Bot mesajları kontrol edilmez
        if message.author.bot:
            return False, ""
        
        # Moderatör yetkileri varsa kontrol edilmez
        if message.author.guild_permissions.manage_messages:
            return False, ""
        
        # Sunucu ayarlarını kontrol et
        try:
            settings = await self.bot.db.get_guild_settings(message.guild.id)
            if not settings or not settings.get('spam_protection_enabled', 1):
                return False, ""
        except:
            pass
        
        user_id = message.author.id
        current_time = datetime.now()
        
        # Kullanıcı mesaj geçmişini al/oluştur
        if user_id not in self.message_history:
            self.message_history[user_id] = []
        
        # Eski mesajları temizle (1 dakikadan eski)
        self.message_history[user_id] = [
            msg_time for msg_time in self.message_history[user_id]
            if current_time - msg_time < timedelta(minutes=1)
        ]
        
        # Yeni mesaj zamanını ekle
        self.message_history[user_id].append(current_time)
        
        # Dakikada mesaj sayısı kontrolü
        if len(self.message_history[user_id]) > self.spam_thresholds['messages_per_minute']:
            return True, "Çok hızlı mesaj gönderimi"
        
        # Büyük harf kontrolü
        if len(message.content) > 10:
            caps_count = sum(1 for c in message.content if c.isupper())
            caps_ratio = caps_count / len(message.content)
            if caps_ratio > self.spam_thresholds['caps_threshold']:
                return True, "Aşırı büyük harf kullanımı"
        
        # Mention spam kontrolü
        mention_count = len(message.mentions) + len(message.role_mentions)
        if mention_count > self.spam_thresholds['mention_threshold']:
            return True, "Aşırı mention kullanımı"
        
        # Tekrarlanan mesaj kontrolü (basit)
        content = message.content.lower().strip()
        if len(content) > 5:
            # Son 5 mesajda aynı içerik var mı kontrol et
            recent_messages = []
            async for msg in message.channel.history(limit=10, before=message):
                if msg.author.id == user_id:
                    recent_messages.append(msg.content.lower().strip())
                    if len(recent_messages) >= 5:
                        break
            
            duplicate_count = recent_messages.count(content)
            if duplicate_count >= self.spam_thresholds['duplicate_threshold']:
                return True, "Tekrarlanan mesaj"
        
        # Veritabanında spam takibi güncelle
        try:
            spam_count = await self.bot.db.update_spam_tracking(message.guild.id, user_id)
            if spam_count > self.spam_thresholds['messages_per_minute']:
                return True, "Dakikada çok fazla mesaj"
        except:
            pass
        
        return False, ""

class AntiRaidProtection:
    """Anti-raid koruması sınıfı"""
    
    def __init__(self, bot):
        self.bot = bot
        self.join_history = {}  # guild_id -> [join_times]
        self.raid_thresholds = {
            'joins_per_minute': 5,      # Dakikada maksimum katılım
            'new_account_days': 7,      # Yeni hesap gün sınırı
            'similar_name_threshold': 3  # Benzer isim sayısı
        }
        self.locked_guilds = set()  # Raid koruması aktif sunucular
    
    async def check_raid(self, member) -> Tuple[bool, str]:
        """
        Raid kontrolü yapar
        Returns: (raid_var_mı, raid_türü)
        """
        guild_id = member.guild.id
        current_time = datetime.now()
        
        # Sunucu ayarlarını kontrol et
        try:
            settings = await self.bot.db.get_guild_settings(guild_id)
            if not settings or not settings.get('anti_raid_enabled', 1):
                return False, ""
        except:
            pass
        
        # Guild katılım geçmişini al/oluştur
        if guild_id not in self.join_history:
            self.join_history[guild_id] = []
        
        # Eski katılımları temizle (1 dakikadan eski)
        self.join_history[guild_id] = [
            join_time for join_time in self.join_history[guild_id]
            if current_time - join_time < timedelta(minutes=1)
        ]
        
        # Yeni katılım zamanını ekle
        self.join_history[guild_id].append(current_time)
        
        # Dakikada katılım sayısı kontrolü
        if len(self.join_history[guild_id]) > self.raid_thresholds['joins_per_minute']:
            return True, "Çok hızlı katılım"
        
        # Yeni hesap kontrolü
        account_age = current_time - member.created_at
        if account_age < timedelta(days=self.raid_thresholds['new_account_days']):
            # Yeni hesapların hızlı katılımını kontrol et
            if len(self.join_history[guild_id]) > 2:
                return True, "Yeni hesapların hızlı katılımı"
        
        # Benzer isim kontrolü
        recent_members = []
        for m in member.guild.members:
            if (current_time - (m.joined_at or current_time)).seconds < 300:  # Son 5 dakika
                recent_members.append(m.display_name.lower())
        
        similar_count = 0
        member_name = member.display_name.lower()
        for name in recent_members:
            if self._similarity_ratio(member_name, name) > 0.8:
                similar_count += 1
        
        if similar_count >= self.raid_thresholds['similar_name_threshold']:
            return True, "Benzer isimli hesapların katılımı"
        
        return False, ""
    
    def _similarity_ratio(self, a: str, b: str) -> float:
        """İki string arasındaki benzerlik oranını hesaplar"""
        if not a or not b:
            return 0.0
        
        # Basit karakter eşleşmesi
        matches = sum(1 for x, y in zip(a, b) if x == y)
        max_len = max(len(a), len(b))
        
        return matches / max_len if max_len > 0 else 0.0
    
    async def activate_raid_protection(self, guild_id: int):
        """Raid korumasını aktif eder"""
        self.locked_guilds.add(guild_id)
        
        # 10 dakika sonra otomatik olarak kaldır
        await asyncio.sleep(600)
        self.locked_guilds.discard(guild_id)
    
    def is_raid_protection_active(self, guild_id: int) -> bool:
        """Raid korumasının aktif olup olmadığını kontrol eder"""
        return guild_id in self.locked_guilds

class MessageHandler:
    """Mesaj işleyici ana sınıfı"""
    
    def __init__(self, bot):
        self.bot = bot
        self.word_filter = WordFilter(bot)
        self.spam_protection = SpamProtection(bot)
        self.anti_raid = AntiRaidProtection(bot)
    
    async def process_message(self, message):
        """Gelen mesajı işler"""
        if not message.guild or message.author.bot:
            return
        
        # Kelime filtresi kontrolü
        is_banned, banned_word, severity = await self.word_filter.check_message(message)
        if is_banned:
            await self._handle_banned_word(message, banned_word, severity)
            return
        
        # Spam kontrolü
        is_spam, spam_type = await self.spam_protection.check_spam(message)
        if is_spam:
            await self._handle_spam(message, spam_type)
            return
    
    async def process_member_join(self, member):
        """Yeni üye katılımını işler"""
        # Anti-raid kontrolü
        is_raid, raid_type = await self.anti_raid.check_raid(member)
        if is_raid:
            await self._handle_raid(member, raid_type)
    
    async def _handle_banned_word(self, message, word, severity):
        """Yasaklı kelime tespit edildiğinde işlem yapar"""
        try:
            # Mesajı sil
            await message.delete()
            
            # Kullanıcıya uyarı
            warning_embed = discord.Embed(
                title="⚠️ Yasaklı Kelime Kullandınız",
                description=f"Mesajınız yasaklı kelime içerdiği için silindi.",
                color=discord.Color.orange()
            )
            
            try:
                await message.author.send(embed=warning_embed)
            except:
                pass
            
            # Şiddete göre işlem yap
            if severity == 1:  # Uyarı
                await self.bot.db.add_warning(
                    message.guild.id,
                    message.author.id,
                    self.bot.user.id,
                    f"Yasaklı kelime kullanımı: {word}"
                )
            elif severity == 2:  # Susturma
                timeout_until = datetime.now() + timedelta(minutes=10)
                await message.author.timeout(timeout_until, reason=f"Yasaklı kelime: {word}")
            elif severity == 3:  # Atma
                await message.author.kick(reason=f"Yasaklı kelime kullanımı: {word}")
            
            # Log mesajı
            await self.bot.db.add_mod_log(
                message.guild.id,
                message.author.id,
                self.bot.user.id,
                "word_filter",
                f"Yasaklı kelime: {word} (Şiddet: {severity})"
            )
            
        except Exception as e:
            print(f"Yasaklı kelime işlenirken hata: {e}")
    
    async def _handle_spam(self, message, spam_type):
        """Spam tespit edildiğinde işlem yapar"""
        try:
            # Mesajı sil
            await message.delete()
            
            # Kullanıcıyı 5 dakika sustur
            timeout_until = datetime.now() + timedelta(minutes=5)
            await message.author.timeout(timeout_until, reason=f"Spam: {spam_type}")
            
            # Uyarı mesajı
            warning_embed = discord.Embed(
                title="🚫 Spam Tespit Edildi",
                description=f"**Sebep:** {spam_type}\n**Ceza:** 5 dakika susturma",
                color=discord.Color.red()
            )
            
            try:
                await message.author.send(embed=warning_embed)
            except:
                pass
            
            # Log mesajı
            await self.bot.db.add_mod_log(
                message.guild.id,
                message.author.id,
                self.bot.user.id,
                "spam_protection",
                spam_type
            )
            
        except Exception as e:
            print(f"Spam işlenirken hata: {e}")
    
    async def _handle_raid(self, member, raid_type):
        """Raid tespit edildiğinde işlem yapar"""
        try:
            # Kullanıcıyı at
            await member.kick(reason=f"Anti-raid koruması: {raid_type}")
            
            # Raid korumasını aktifleştir
            await self.anti_raid.activate_raid_protection(member.guild.id)
            
            # Log mesajı
            await self.bot.db.add_mod_log(
                member.guild.id,
                member.id,
                self.bot.user.id,
                "anti_raid",
                raid_type
            )
            
        except Exception as e:
            print(f"Raid koruması işlenirken hata: {e}")

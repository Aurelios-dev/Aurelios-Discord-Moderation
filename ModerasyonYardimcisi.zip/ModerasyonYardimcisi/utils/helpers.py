import json
import os
from typing import Dict, Any, Optional
import discord
from discord.ext import commands

def load_config() -> Dict[str, Any]:
    """Konfigürasyon dosyasını yükler"""
    config_path = "config.json"
    
    try:
        if os.path.exists(config_path):
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        else:
            # Varsayılan config oluştur
            default_config = {
                "default_prefix": "!",
                "default_language": "tr",
                "bot_name": "Türkçe Moderasyon Botu",
                "bot_description": "Sunucunuzu güvende tutmak için tasarlanmış kapsamlı moderasyon botu",
                "embed_color": "0x3498db",
                "support_server": "",
                "owner_ids": [],
                "blacklisted_users": [],
                "maintenance_mode": False,
                "debug_mode": False
            }
            
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(default_config, f, indent=4, ensure_ascii=False)
            
            return default_config
            
    except Exception as e:
        print(f"Config yüklenirken hata: {e}")
        return {}

def save_config(config: Dict[str, Any]) -> bool:
    """Konfigürasyonu dosyaya kaydeder"""
    config_path = "config.json"
    
    try:
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=4, ensure_ascii=False)
        return True
    except Exception as e:
        print(f"Config kaydedilirken hata: {e}")
        return False

async def get_prefix(bot, message) -> str:
    """Bot prefix'ini getirir"""
    if not message.guild:
        return bot.config.get("default_prefix", "!")
    
    try:
        # Veritabanından sunucu prefix'ini al
        settings = await bot.db.get_guild_settings(message.guild.id)
        if settings and settings.get('prefix'):
            return settings['prefix']
    except:
        pass
    
    return bot.config.get("default_prefix", "!")

def format_time(seconds: int) -> str:
    """Saniyeyi okunabilir formata çevirir"""
    if seconds < 60:
        return f"{seconds} saniye"
    elif seconds < 3600:
        minutes = seconds // 60
        remaining_seconds = seconds % 60
        if remaining_seconds == 0:
            return f"{minutes} dakika"
        return f"{minutes} dakika {remaining_seconds} saniye"
    elif seconds < 86400:
        hours = seconds // 3600
        remaining_minutes = (seconds % 3600) // 60
        if remaining_minutes == 0:
            return f"{hours} saat"
        return f"{hours} saat {remaining_minutes} dakika"
    else:
        days = seconds // 86400
        remaining_hours = (seconds % 86400) // 3600
        if remaining_hours == 0:
            return f"{days} gün"
        return f"{days} gün {remaining_hours} saat"

def parse_time(time_string: str) -> Optional[int]:
    """Zaman string'ini saniyeye çevirir (örn: '1h30m' -> 5400)"""
    import re
    
    # Zaman pattern'i
    pattern = r'(?:(\d+)d)?(?:(\d+)h)?(?:(\d+)m)?(?:(\d+)s)?'
    match = re.match(pattern, time_string.lower())
    
    if not match:
        return None
    
    days, hours, minutes, seconds = match.groups()
    
    total_seconds = 0
    if days:
        total_seconds += int(days) * 86400
    if hours:
        total_seconds += int(hours) * 3600
    if minutes:
        total_seconds += int(minutes) * 60
    if seconds:
        total_seconds += int(seconds)
    
    return total_seconds if total_seconds > 0 else None

def create_embed(
    title: str,
    description: str = "",
    color: discord.Color = discord.Color.blue(),
    footer: str = None,
    author: dict = None,
    fields: list = None,
    thumbnail: str = None,
    image: str = None
) -> discord.Embed:
    """Standart embed oluşturur"""
    
    embed = discord.Embed(
        title=title,
        description=description,
        color=color
    )
    
    if footer:
        embed.set_footer(text=footer)
    
    if author:
        embed.set_author(
            name=author.get('name', ''),
            icon_url=author.get('icon_url', ''),
            url=author.get('url', '')
        )
    
    if fields:
        for field in fields:
            embed.add_field(
                name=field.get('name', ''),
                value=field.get('value', ''),
                inline=field.get('inline', True)
            )
    
    if thumbnail:
        embed.set_thumbnail(url=thumbnail)
    
    if image:
        embed.set_image(url=image)
    
    return embed

def create_error_embed(message: str, title: str = "❌ Hata") -> discord.Embed:
    """Hata embed'i oluşturur"""
    return discord.Embed(
        title=title,
        description=message,
        color=discord.Color.red()
    )

def create_success_embed(message: str, title: str = "✅ Başarılı") -> discord.Embed:
    """Başarı embed'i oluşturur"""
    return discord.Embed(
        title=title,
        description=message,
        color=discord.Color.green()
    )

def create_warning_embed(message: str, title: str = "⚠️ Uyarı") -> discord.Embed:
    """Uyarı embed'i oluşturur"""
    return discord.Embed(
        title=title,
        description=message,
        color=discord.Color.orange()
    )

def create_info_embed(message: str, title: str = "ℹ️ Bilgi") -> discord.Embed:
    """Bilgi embed'i oluşturur"""
    return discord.Embed(
        title=title,
        description=message,
        color=discord.Color.blue()
    )

def check_permissions(user: discord.Member, required_permissions: list) -> tuple[bool, list]:
    """
    Kullanıcının gerekli yetkilere sahip olup olmadığını kontrol eder
    Returns: (has_permissions, missing_permissions)
    """
    missing_permissions = []
    
    for permission in required_permissions:
        if not getattr(user.guild_permissions, permission, False):
            missing_permissions.append(permission)
    
    return len(missing_permissions) == 0, missing_permissions

def format_permissions(permissions: list) -> str:
    """Yetki listesini Türkçe formatlar"""
    permission_names = {
        'administrator': 'Yönetici',
        'kick_members': 'Üyeleri At',
        'ban_members': 'Üyeleri Yasakla',
        'manage_messages': 'Mesajları Yönet',
        'manage_roles': 'Rolleri Yönet',
        'manage_channels': 'Kanalları Yönet',
        'manage_guild': 'Sunucuyu Yönet',
        'moderate_members': 'Üyeleri Zaman Aşımına Uğrat',
        'view_audit_log': 'Denetim Günlüğünü Görüntüle',
        'send_messages': 'Mesaj Gönder',
        'embed_links': 'Bağlantı Yerleştir',
        'attach_files': 'Dosya Ekle',
        'read_message_history': 'Mesaj Geçmişini Oku',
        'add_reactions': 'Tepki Ekle',
        'use_slash_commands': 'Slash Komutları Kullan'
    }
    
    formatted = []
    for permission in permissions:
        formatted.append(permission_names.get(permission, permission))
    
    return ', '.join(formatted)

def truncate_text(text: str, max_length: int = 2000, suffix: str = "...") -> str:
    """Metni belirtilen uzunlukta keser"""
    if len(text) <= max_length:
        return text
    
    return text[:max_length - len(suffix)] + suffix

def format_user_mention(user_id: int) -> str:
    """Kullanıcı ID'sini mention formatına çevirir"""
    return f"<@{user_id}>"

def format_channel_mention(channel_id: int) -> str:
    """Kanal ID'sini mention formatına çevirir"""
    return f"<#{channel_id}>"

def format_role_mention(role_id: int) -> str:
    """Rol ID'sini mention formatına çevirir"""
    return f"<@&{role_id}>"

def get_user_color(user: discord.Member) -> discord.Color:
    """Kullanıcının rengini getirir"""
    if user.color.value != 0:
        return user.color
    return discord.Color.blue()

def is_url(text: str) -> bool:
    """Metnin URL olup olmadığını kontrol eder"""
    import re
    url_pattern = re.compile(
        r'^https?://'  # http:// or https://
        r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+[A-Z]{2,6}\.?|'  # domain...
        r'localhost|'  # localhost...
        r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})'  # ...or ip
        r'(?::\d+)?'  # optional port
        r'(?:/?|[/?]\S+)$', re.IGNORECASE)
    
    return url_pattern.match(text) is not None

def clean_text(text: str) -> str:
    """Metni temizler (özel karakterler, fazla boşluklar vb.)"""
    import re
    
    # Fazla boşlukları temizle
    text = re.sub(r'\s+', ' ', text)
    
    # Başındaki ve sonundaki boşlukları temizle
    text = text.strip()
    
    return text

def validate_color(color_string: str) -> Optional[discord.Color]:
    """Color string'ini discord.Color objesine çevirir"""
    try:
        # Hex color (örn: #ff0000, 0xff0000, ff0000)
        if color_string.startswith('#'):
            color_string = color_string[1:]
        elif color_string.startswith('0x'):
            color_string = color_string[2:]
        
        # RGB değerini al
        rgb_value = int(color_string, 16)
        
        # Discord Color limitlerini kontrol et
        if 0 <= rgb_value <= 0xffffff:
            return discord.Color(rgb_value)
        
    except ValueError:
        pass
    
    # Öntanımlı renkler
    color_names = {
        'red': discord.Color.red(),
        'green': discord.Color.green(),
        'blue': discord.Color.blue(),
        'yellow': discord.Color.yellow(),
        'orange': discord.Color.orange(),
        'purple': discord.Color.purple(),
        'pink': discord.Color.magenta(),
        'black': discord.Color.from_rgb(0, 0, 0),
        'white': discord.Color.from_rgb(255, 255, 255)
    }
    
    return color_names.get(color_string.lower())

class BotConfig:
    """Bot konfigürasyon yöneticisi"""
    
    def __init__(self, config_path: str = "config.json"):
        self.config_path = config_path
        self.config = load_config()
    
    def get(self, key: str, default=None):
        """Konfigürasyon değerini getirir"""
        return self.config.get(key, default)
    
    def set(self, key: str, value):
        """Konfigürasyon değerini ayarlar"""
        self.config[key] = value
        return save_config(self.config)
    
    def reload(self):
        """Konfigürasyonu yeniden yükler"""
        self.config = load_config()
    
    def is_owner(self, user_id: int) -> bool:
        """Kullanıcının bot sahibi olup olmadığını kontrol eder"""
        owner_ids = self.config.get('owner_ids', [])
        return user_id in owner_ids
    
    def is_blacklisted(self, user_id: int) -> bool:
        """Kullanıcının kara listede olup olmadığını kontrol eder"""
        blacklisted = self.config.get('blacklisted_users', [])
        return user_id in blacklisted
    
    def is_maintenance_mode(self) -> bool:
        """Bakım modunun aktif olup olmadığını kontrol eder"""
        return self.config.get('maintenance_mode', False)
    
    def is_debug_mode(self) -> bool:
        """Debug modunun aktif olup olmadığını kontrol eder"""
        return self.config.get('debug_mode', False)

# Global değişkenler
_bot_config = None

def get_bot_config() -> BotConfig:
    """Global bot config'ini getirir"""
    global _bot_config
    if _bot_config is None:
        _bot_config = BotConfig()
    return _bot_config

import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime
import asyncio

class LoggingCog(commands.Cog):
    """Loglama sistemi"""
    
    def __init__(self, bot):
        self.bot = bot
        self.deleted_messages = {}  # Silinen mesajları geçici olarak sakla
    
    async def get_log_channel(self, guild_id):
        """Log kanalını al"""
        settings = await self.bot.db.get_guild_settings(guild_id)
        if settings and settings.get('log_channel'):
            return self.bot.get_channel(settings['log_channel'])
        return None
    
    async def send_log(self, guild_id, embed):
        """Log mesajı gönder"""
        log_channel = await self.get_log_channel(guild_id)
        if log_channel:
            try:
                await log_channel.send(embed=embed)
            except:
                pass
    
    @commands.Cog.listener()
    async def on_message_delete(self, message):
        """Mesaj silindiğinde log"""
        if message.author.bot:
            return
        
        # Mesajı geçici olarak sakla
        self.deleted_messages[message.id] = message
        
        embed = discord.Embed(
            title="🗑️ Mesaj Silindi",
            color=discord.Color.red(),
            timestamp=datetime.now()
        )
        embed.add_field(name="Kullanıcı", value=message.author.mention, inline=True)
        embed.add_field(name="Kanal", value=message.channel.mention, inline=True)
        embed.add_field(name="Mesaj ID", value=message.id, inline=True)
        
        if message.content:
            content = message.content[:1000] + "..." if len(message.content) > 1000 else message.content
            embed.add_field(name="İçerik", value=f"```{content}```", inline=False)
        
        if message.attachments:
            attachments = "\n".join([att.filename for att in message.attachments])
            embed.add_field(name="Ekler", value=attachments, inline=False)
        
        embed.set_author(name=message.author.display_name, icon_url=message.author.display_avatar.url)
        
        await self.send_log(message.guild.id, embed)
    
    @commands.Cog.listener()
    async def on_bulk_message_delete(self, messages):
        """Toplu mesaj silindiğinde log"""
        if not messages:
            return
        
        guild = messages[0].guild
        channel = messages[0].channel
        
        embed = discord.Embed(
            title="🗑️ Toplu Mesaj Silindi",
            description=f"**Kanal:** {channel.mention}\n**Silinen Mesaj Sayısı:** {len(messages)}",
            color=discord.Color.red(),
            timestamp=datetime.now()
        )
        
        # Son 10 mesajı göster
        message_list = []
        for message in messages[-10:]:
            if not message.author.bot and message.content:
                content = message.content[:50] + "..." if len(message.content) > 50 else message.content
                message_list.append(f"**{message.author.display_name}:** {content}")
        
        if message_list:
            embed.add_field(name="Son Mesajlar", value="\n".join(message_list), inline=False)
        
        await self.send_log(guild.id, embed)
    
    @commands.Cog.listener()
    async def on_message_edit(self, before, after):
        """Mesaj düzenlendiğinde log"""
        if before.author.bot or before.content == after.content:
            return
        
        embed = discord.Embed(
            title="✏️ Mesaj Düzenlendi",
            color=discord.Color.orange(),
            timestamp=datetime.now()
        )
        embed.add_field(name="Kullanıcı", value=before.author.mention, inline=True)
        embed.add_field(name="Kanal", value=before.channel.mention, inline=True)
        embed.add_field(name="Mesaj ID", value=before.id, inline=True)
        
        if before.content:
            content = before.content[:500] + "..." if len(before.content) > 500 else before.content
            embed.add_field(name="Önceki İçerik", value=f"```{content}```", inline=False)
        
        if after.content:
            content = after.content[:500] + "..." if len(after.content) > 500 else after.content
            embed.add_field(name="Yeni İçerik", value=f"```{content}```", inline=False)
        
        embed.set_author(name=before.author.display_name, icon_url=before.author.display_avatar.url)
        
        await self.send_log(before.guild.id, embed)
    
    @commands.Cog.listener()
    async def on_member_join(self, member):
        """Üye katıldığında log ve hoşgeldin mesajı"""
        # Hoşgeldin mesajı
        settings = await self.bot.db.get_guild_settings(member.guild.id)
        if settings and settings.get('welcome_channel'):
            welcome_channel = self.bot.get_channel(settings['welcome_channel'])
            if welcome_channel:
                try:
                    welcome_msg = settings.get('welcome_message', 
                        f"🎉 Hoş geldin {member.mention}! Sunucumuza katıldığın için teşekkürler!")
                    
                    # Placeholder'ları değiştir
                    welcome_msg = welcome_msg.replace("{user}", member.mention)
                    welcome_msg = welcome_msg.replace("{server}", member.guild.name)
                    welcome_msg = welcome_msg.replace("{count}", str(member.guild.member_count))
                    
                    embed = discord.Embed(
                        title="🎉 Hoş Geldin!",
                        description=welcome_msg,
                        color=discord.Color.green()
                    )
                    embed.set_thumbnail(url=member.display_avatar.url)
                    embed.set_footer(text=f"Üye #{member.guild.member_count}")
                    
                    await welcome_channel.send(embed=embed)
                except:
                    pass
        
        # Log mesajı
        embed = discord.Embed(
            title="📥 Üye Katıldı",
            color=discord.Color.green(),
            timestamp=datetime.now()
        )
        embed.add_field(name="Kullanıcı", value=member.mention, inline=True)
        embed.add_field(name="ID", value=member.id, inline=True)
        embed.add_field(name="Hesap Oluşturma", value=f"<t:{int(member.created_at.timestamp())}:R>", inline=True)
        embed.add_field(name="Üye Sayısı", value=member.guild.member_count, inline=True)
        
        embed.set_author(name=member.display_name, icon_url=member.display_avatar.url)
        embed.set_footer(text=f"Üye #{member.guild.member_count}")
        
        await self.send_log(member.guild.id, embed)
    
    @commands.Cog.listener()
    async def on_member_remove(self, member):
        """Üye ayrıldığında log ve veda mesajı"""
        # Veda mesajı
        settings = await self.bot.db.get_guild_settings(member.guild.id)
        if settings and settings.get('goodbye_channel'):
            goodbye_channel = self.bot.get_channel(settings['goodbye_channel'])
            if goodbye_channel:
                try:
                    goodbye_msg = settings.get('goodbye_message', 
                        f"👋 {member.display_name} sunucudan ayrıldı. Görüşürüz!")
                    
                    # Placeholder'ları değiştir
                    goodbye_msg = goodbye_msg.replace("{user}", member.display_name)
                    goodbye_msg = goodbye_msg.replace("{server}", member.guild.name)
                    goodbye_msg = goodbye_msg.replace("{count}", str(member.guild.member_count))
                    
                    embed = discord.Embed(
                        title="👋 Güle Güle",
                        description=goodbye_msg,
                        color=discord.Color.orange()
                    )
                    embed.set_thumbnail(url=member.display_avatar.url)
                    
                    await goodbye_channel.send(embed=embed)
                except:
                    pass
        
        # Log mesajı
        embed = discord.Embed(
            title="📤 Üye Ayrıldı",
            color=discord.Color.red(),
            timestamp=datetime.now()
        )
        embed.add_field(name="Kullanıcı", value=f"{member.display_name} ({member.id})", inline=True)
        embed.add_field(name="Katılma Tarihi", value=f"<t:{int(member.joined_at.timestamp())}:R>" if member.joined_at else "Bilinmiyor", inline=True)
        embed.add_field(name="Üye Sayısı", value=member.guild.member_count, inline=True)
        
        roles = [role.mention for role in member.roles[1:]]  # @everyone rolünü atla
        if roles:
            embed.add_field(name="Roller", value=", ".join(roles), inline=False)
        
        embed.set_author(name=member.display_name, icon_url=member.display_avatar.url)
        
        await self.send_log(member.guild.id, embed)
    
    @commands.Cog.listener()
    async def on_member_update(self, before, after):
        """Üye güncellendiğinde log"""
        # Nickname değişimi
        if before.nick != after.nick:
            embed = discord.Embed(
                title="✏️ Nickname Değişti",
                color=discord.Color.blue(),
                timestamp=datetime.now()
            )
            embed.add_field(name="Kullanıcı", value=after.mention, inline=True)
            embed.add_field(name="Önceki", value=before.nick or before.name, inline=True)
            embed.add_field(name="Yeni", value=after.nick or after.name, inline=True)
            
            embed.set_author(name=after.display_name, icon_url=after.display_avatar.url)
            
            await self.send_log(after.guild.id, embed)
        
        # Rol değişimi
        if before.roles != after.roles:
            added_roles = set(after.roles) - set(before.roles)
            removed_roles = set(before.roles) - set(after.roles)
            
            if added_roles or removed_roles:
                embed = discord.Embed(
                    title="🔄 Rol Değişimi",
                    color=discord.Color.blue(),
                    timestamp=datetime.now()
                )
                embed.add_field(name="Kullanıcı", value=after.mention, inline=True)
                
                if added_roles:
                    embed.add_field(name="Eklenen Roller", value=", ".join([role.mention for role in added_roles]), inline=False)
                
                if removed_roles:
                    embed.add_field(name="Kaldırılan Roller", value=", ".join([role.mention for role in removed_roles]), inline=False)
                
                embed.set_author(name=after.display_name, icon_url=after.display_avatar.url)
                
                await self.send_log(after.guild.id, embed)
    
    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        """Ses durumu değiştiğinde log"""
        # Ses kanalına katılma
        if before.channel is None and after.channel is not None:
            embed = discord.Embed(
                title="🔊 Ses Kanalına Katıldı",
                color=discord.Color.green(),
                timestamp=datetime.now()
            )
            embed.add_field(name="Kullanıcı", value=member.mention, inline=True)
            embed.add_field(name="Kanal", value=after.channel.mention, inline=True)
            
            embed.set_author(name=member.display_name, icon_url=member.display_avatar.url)
            
            await self.send_log(member.guild.id, embed)
        
        # Ses kanalından ayrılma
        elif before.channel is not None and after.channel is None:
            embed = discord.Embed(
                title="🔇 Ses Kanalından Ayrıldı",
                color=discord.Color.red(),
                timestamp=datetime.now()
            )
            embed.add_field(name="Kullanıcı", value=member.mention, inline=True)
            embed.add_field(name="Kanal", value=before.channel.mention, inline=True)
            
            embed.set_author(name=member.display_name, icon_url=member.display_avatar.url)
            
            await self.send_log(member.guild.id, embed)
        
        # Ses kanalı değiştirme
        elif before.channel != after.channel and before.channel is not None and after.channel is not None:
            embed = discord.Embed(
                title="🔄 Ses Kanalı Değiştirdi",
                color=discord.Color.blue(),
                timestamp=datetime.now()
            )
            embed.add_field(name="Kullanıcı", value=member.mention, inline=True)
            embed.add_field(name="Önceki Kanal", value=before.channel.mention, inline=True)
            embed.add_field(name="Yeni Kanal", value=after.channel.mention, inline=True)
            
            embed.set_author(name=member.display_name, icon_url=member.display_avatar.url)
            
            await self.send_log(member.guild.id, embed)
    
    @app_commands.command(name="log-kanal", description="Log kanalını ayarlar")
    @app_commands.describe(kanal="Log mesajlarının gönderileceği kanal")
    async def set_log_channel(self, interaction: discord.Interaction, kanal: discord.TextChannel):
        """Log kanalını ayarlar"""
        
        # Yetki kontrolü
        if not interaction.user.guild_permissions.manage_guild:
            embed = discord.Embed(
                title="❌ Yetki Hatası",
                description="Bu komutu kullanmak için 'Sunucuyu Yönet' yetkisine sahip olmalısınız.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            # Sunucu ayarlarını güncelle
            await self.bot.db.update_guild_setting(interaction.guild.id, 'log_channel', kanal.id)
            
            embed = discord.Embed(
                title="✅ Log Kanalı Ayarlandı",
                description=f"Log mesajları artık {kanal.mention} kanalına gönderilecek.",
                color=discord.Color.green()
            )
            await interaction.response.send_message(embed=embed)
            
        except Exception as e:
            embed = discord.Embed(
                title="❌ Hata",
                description=f"Log kanalı ayarlanırken bir hata oluştu: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="hosgeldin-ayarla", description="Hoşgeldin kanalını ve mesajını ayarlar")
    @app_commands.describe(
        kanal="Hoşgeldin mesajlarının gönderileceği kanal",
        mesaj="Hoşgeldin mesajı ({user}, {server}, {count} kullanılabilir)"
    )
    async def set_welcome(self, interaction: discord.Interaction, kanal: discord.TextChannel, mesaj: str = None):
        """Hoşgeldin kanalını ve mesajını ayarlar"""
        
        # Yetki kontrolü
        if not interaction.user.guild_permissions.manage_guild:
            embed = discord.Embed(
                title="❌ Yetki Hatası",
                description="Bu komutu kullanmak için 'Sunucuyu Yönet' yetkisine sahip olmalısınız.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            # Sunucu ayarlarını güncelle
            await self.bot.db.update_guild_setting(interaction.guild.id, 'welcome_channel', kanal.id)
            
            if mesaj:
                await self.bot.db.update_guild_setting(interaction.guild.id, 'welcome_message', mesaj)
            
            embed = discord.Embed(
                title="✅ Hoşgeldin Sistemi Ayarlandı",
                description=f"Hoşgeldin mesajları artık {kanal.mention} kanalına gönderilecek.",
                color=discord.Color.green()
            )
            
            if mesaj:
                embed.add_field(name="Mesaj", value=mesaj, inline=False)
                embed.add_field(name="Kullanılabilir Değişkenler", value="{user} - Kullanıcı mention\n{server} - Sunucu adı\n{count} - Üye sayısı", inline=False)
            
            await interaction.response.send_message(embed=embed)
            
        except Exception as e:
            embed = discord.Embed(
                title="❌ Hata",
                description=f"Hoşgeldin sistemi ayarlanırken bir hata oluştu: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="veda-ayarla", description="Veda kanalını ve mesajını ayarlar")
    @app_commands.describe(
        kanal="Veda mesajlarının gönderileceği kanal",
        mesaj="Veda mesajı ({user}, {server}, {count} kullanılabilir)"
    )
    async def set_goodbye(self, interaction: discord.Interaction, kanal: discord.TextChannel, mesaj: str = None):
        """Veda kanalını ve mesajını ayarlar"""
        
        # Yetki kontrolü
        if not interaction.user.guild_permissions.manage_guild:
            embed = discord.Embed(
                title="❌ Yetki Hatası",
                description="Bu komutu kullanmak için 'Sunucuyu Yönet' yetkisine sahip olmalısınız.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            # Sunucu ayarlarını güncelle
            await self.bot.db.update_guild_setting(interaction.guild.id, 'goodbye_channel', kanal.id)
            
            if mesaj:
                await self.bot.db.update_guild_setting(interaction.guild.id, 'goodbye_message', mesaj)
            
            embed = discord.Embed(
                title="✅ Veda Sistemi Ayarlandı",
                description=f"Veda mesajları artık {kanal.mention} kanalına gönderilecek.",
                color=discord.Color.green()
            )
            
            if mesaj:
                embed.add_field(name="Mesaj", value=mesaj, inline=False)
                embed.add_field(name="Kullanılabilir Değişkenler", value="{user} - Kullanıcı adı\n{server} - Sunucu adı\n{count} - Üye sayısı", inline=False)
            
            await interaction.response.send_message(embed=embed)
            
        except Exception as e:
            embed = discord.Embed(
                title="❌ Hata",
                description=f"Veda sistemi ayarlanırken bir hata oluştu: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)

async def setup(bot):
    await bot.add_cog(LoggingCog(bot))

import discord
from discord.ext import commands
from discord import app_commands
from typing import Optional

class AutoRoleCog(commands.Cog):
    """Otomatik rol sistemi"""
    
    def __init__(self, bot):
        self.bot = bot
    
    @commands.Cog.listener()
    async def on_member_join(self, member):
        """Yeni üye katıldığında otomatik rol verme"""
        try:
            # Sunucu ayarlarını al
            settings = await self.bot.db.get_guild_settings(member.guild.id)
            if not settings or not settings.get('autorole_enabled'):
                return
            
            # Katılım tipi otomatik rolleri al
            auto_roles = await self.bot.db.get_auto_roles(member.guild.id, 'join')
            
            for role_data in auto_roles:
                role = member.guild.get_role(role_data[2])  # role_id
                if role and not role in member.roles:
                    try:
                        await member.add_roles(role, reason="Otomatik rol sistemi")
                        print(f"✅ {member.display_name} kullanıcısına {role.name} rolü verildi")
                    except discord.Forbidden:
                        print(f"❌ {role.name} rolü verilemedi - Yetki yok")
                    except Exception as e:
                        print(f"❌ {role.name} rolü verilirken hata: {e}")
        
        except Exception as e:
            print(f"❌ Otomatik rol sistemi hatası: {e}")
    
    @commands.Cog.listener()
    async def on_raw_reaction_add(self, payload):
        """Reaksiyon ile rol verme"""
        try:
            # Bot reaksiyonlarını yoksay
            if payload.user_id == self.bot.user.id:
                return
            
            guild = self.bot.get_guild(payload.guild_id)
            if not guild:
                return
            
            member = guild.get_member(payload.user_id)
            if not member:
                return
            
            # Reaksiyon tipi otomatik rolleri al
            auto_roles = await self.bot.db.get_auto_roles(guild.id, 'reaction')
            
            for role_data in auto_roles:
                # trigger_value formatı: "kanal_id:mesaj_id:emoji"
                trigger_parts = role_data[4].split(':')  # trigger_value
                if len(trigger_parts) != 3:
                    continue
                
                channel_id, message_id, emoji = trigger_parts
                
                if (str(payload.channel_id) == channel_id and 
                    str(payload.message_id) == message_id and 
                    str(payload.emoji) == emoji):
                    
                    role = guild.get_role(role_data[2])  # role_id
                    if role and role not in member.roles:
                        try:
                            await member.add_roles(role, reason="Reaksiyon ile otomatik rol")
                            print(f"✅ {member.display_name} kullanıcısına {role.name} rolü verildi (reaksiyon)")
                        except discord.Forbidden:
                            print(f"❌ {role.name} rolü verilemedi - Yetki yok")
                        except Exception as e:
                            print(f"❌ {role.name} rolü verilirken hata: {e}")
        
        except Exception as e:
            print(f"❌ Reaksiyon rol sistemi hatası: {e}")
    
    @commands.Cog.listener()
    async def on_raw_reaction_remove(self, payload):
        """Reaksiyon kaldırıldığında rol alma"""
        try:
            # Bot reaksiyonlarını yoksay
            if payload.user_id == self.bot.user.id:
                return
            
            guild = self.bot.get_guild(payload.guild_id)
            if not guild:
                return
            
            member = guild.get_member(payload.user_id)
            if not member:
                return
            
            # Reaksiyon tipi otomatik rolleri al
            auto_roles = await self.bot.db.get_auto_roles(guild.id, 'reaction')
            
            for role_data in auto_roles:
                # trigger_value formatı: "kanal_id:mesaj_id:emoji"
                trigger_parts = role_data[4].split(':')  # trigger_value
                if len(trigger_parts) != 3:
                    continue
                
                channel_id, message_id, emoji = trigger_parts
                
                if (str(payload.channel_id) == channel_id and 
                    str(payload.message_id) == message_id and 
                    str(payload.emoji) == emoji):
                    
                    role = guild.get_role(role_data[2])  # role_id
                    if role and role in member.roles:
                        try:
                            await member.remove_roles(role, reason="Reaksiyon kaldırıldı")
                            print(f"✅ {member.display_name} kullanıcısından {role.name} rolü alındı")
                        except discord.Forbidden:
                            print(f"❌ {role.name} rolü alınamadı - Yetki yok")
                        except Exception as e:
                            print(f"❌ {role.name} rolü alınırken hata: {e}")
        
        except Exception as e:
            print(f"❌ Reaksiyon rol sistemi hatası: {e}")
    
    @app_commands.command(name="otorol-ekle", description="Otomatik rol sistemi ekler")
    @app_commands.describe(
        rol="Verilecek rol",
        tür="Rol verme türü",
        kanal="Reaksiyon için kanal (sadece reaksiyon türü için)",
        mesaj_id="Reaksiyon için mesaj ID (sadece reaksiyon türü için)",
        emoji="Reaksiyon için emoji (sadece reaksiyon türü için)"
    )
    @app_commands.choices(tür=[
        app_commands.Choice(name="Katılımda Otomatik", value="join"),
        app_commands.Choice(name="Reaksiyon ile", value="reaction")
    ])
    async def add_autorole(
        self, 
        interaction: discord.Interaction, 
        rol: discord.Role, 
        tür: str,
        kanal: Optional[discord.TextChannel] = None,
        mesaj_id: Optional[str] = None,
        emoji: Optional[str] = None
    ):
        """Otomatik rol sistemi ekler"""
        
        # Yetki kontrolü
        if not interaction.user.guild_permissions.manage_roles:
            embed = discord.Embed(
                title="❌ Yetki Hatası",
                description="Bu komutu kullanmak için 'Rolleri Yönet' yetkisine sahip olmalısınız.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Bot rol yetki kontrolü
        if rol >= interaction.guild.me.top_role:
            embed = discord.Embed(
                title="❌ Rol Hatası",
                description="Bu rol benim en üst rolümden yüksek veya eşit konumda!",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Reaksiyon türü için ek parametreler kontrolü
        if tür == "reaction":
            if not kanal or not mesaj_id or not emoji:
                embed = discord.Embed(
                    title="❌ Eksik Parametre",
                    description="Reaksiyon türü için kanal, mesaj ID ve emoji gereklidir!",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            # Mesaj ID kontrolü
            try:
                int(mesaj_id)
            except ValueError:
                embed = discord.Embed(
                    title="❌ Hata",
                    description="Geçersiz mesaj ID!",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            # Mesajın var olup olmadığını kontrol et
            try:
                message = await kanal.fetch_message(int(mesaj_id))
                # Mesaja emoji ekle
                await message.add_reaction(emoji)
            except discord.NotFound:
                embed = discord.Embed(
                    title="❌ Hata",
                    description="Belirtilen mesaj bulunamadı!",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            except discord.InvalidArgument:
                embed = discord.Embed(
                    title="❌ Hata",
                    description="Geçersiz emoji!",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            except Exception as e:
                embed = discord.Embed(
                    title="❌ Hata",
                    description=f"Mesaj kontrol edilirken hata oluştu: {str(e)}",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
        
        try:
            # Trigger value oluştur
            trigger_value = ""
            if tür == "reaction":
                trigger_value = f"{kanal.id}:{mesaj_id}:{emoji}"
            
            # Otomatik rol ekle
            await self.bot.db.add_auto_role(
                interaction.guild.id,
                rol.id,
                tür,
                trigger_value
            )
            
            # Başarı mesajı
            embed = discord.Embed(
                title="✅ Otomatik Rol Eklendi",
                description=f"**Rol:** {rol.mention}\n**Tür:** {tür}",
                color=discord.Color.green()
            )
            
            if tür == "join":
                embed.add_field(name="📝 Açıklama", value="Yeni katılan üyelere otomatik olarak verilecek", inline=False)
            elif tür == "reaction":
                embed.add_field(name="📝 Açıklama", value=f"Kanal: {kanal.mention}\nMesaj ID: {mesaj_id}\nEmoji: {emoji}", inline=False)
            
            await interaction.response.send_message(embed=embed)
            
            # Otomatik rol sistemini etkinleştir
            await self.bot.db.update_guild_setting(interaction.guild.id, 'autorole_enabled', 1)
            
        except Exception as e:
            embed = discord.Embed(
                title="❌ Hata",
                description=f"Otomatik rol eklenirken bir hata oluştu: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="otorol-sil", description="Otomatik rol sistemini kaldırır")
    @app_commands.describe(rol="Kaldırılacak otomatik rol")
    async def remove_autorole(self, interaction: discord.Interaction, rol: discord.Role):
        """Otomatik rol sistemini kaldırır"""
        
        # Yetki kontrolü
        if not interaction.user.guild_permissions.manage_roles:
            embed = discord.Embed(
                title="❌ Yetki Hatası",
                description="Bu komutu kullanmak için 'Rolleri Yönet' yetkisine sahip olmalısınız.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            # Otomatik rol sil
            await self.bot.db.remove_auto_role(interaction.guild.id, rol.id)
            
            # Başarı mesajı
            embed = discord.Embed(
                title="✅ Otomatik Rol Kaldırıldı",
                description=f"**Rol:** {rol.mention} artık otomatik olarak verilmeyecek.",
                color=discord.Color.green()
            )
            await interaction.response.send_message(embed=embed)
            
        except Exception as e:
            embed = discord.Embed(
                title="❌ Hata",
                description=f"Otomatik rol kaldırılırken bir hata oluştu: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="otorol-liste", description="Otomatik rol listesini gösterir")
    async def list_autoroles(self, interaction: discord.Interaction):
        """Otomatik rol listesini gösterir"""
        
        # Yetki kontrolü
        if not interaction.user.guild_permissions.manage_roles:
            embed = discord.Embed(
                title="❌ Yetki Hatası",
                description="Bu komutu kullanmak için 'Rolleri Yönet' yetkisine sahip olmalısınız.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            auto_roles = await self.bot.db.get_auto_roles(interaction.guild.id)
            
            if not auto_roles:
                embed = discord.Embed(
                    title="📋 Otomatik Rol Listesi",
                    description="Henüz otomatik rol tanımlanmamış.",
                    color=discord.Color.blue()
                )
                await interaction.response.send_message(embed=embed)
                return
            
            embed = discord.Embed(
                title="📋 Otomatik Rol Listesi",
                description=f"Toplam {len(auto_roles)} otomatik rol tanımı",
                color=discord.Color.blue()
            )
            
            join_roles = []
            reaction_roles = []
            
            for role_data in auto_roles:
                role = interaction.guild.get_role(role_data[2])  # role_id
                if not role:
                    continue
                
                if role_data[3] == "join":  # trigger_type
                    join_roles.append(role.mention)
                elif role_data[3] == "reaction":
                    trigger_parts = role_data[4].split(':')  # trigger_value
                    if len(trigger_parts) == 3:
                        channel_id, message_id, emoji = trigger_parts
                        channel = interaction.guild.get_channel(int(channel_id))
                        channel_mention = channel.mention if channel else "Bilinmeyen Kanal"
                        reaction_roles.append(f"{role.mention} - {channel_mention} ({emoji})")
            
            if join_roles:
                embed.add_field(
                    name="🎉 Katılımda Otomatik",
                    value="\n".join(join_roles),
                    inline=False
                )
            
            if reaction_roles:
                embed.add_field(
                    name="⚡ Reaksiyon ile",
                    value="\n".join(reaction_roles),
                    inline=False
                )
            
            await interaction.response.send_message(embed=embed)
            
        except Exception as e:
            embed = discord.Embed(
                title="❌ Hata",
                description=f"Otomatik roller listelenirken bir hata oluştu: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)

async def setup(bot):
    await bot.add_cog(AutoRoleCog(bot))

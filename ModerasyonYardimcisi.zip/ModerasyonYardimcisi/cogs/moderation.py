import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime, timedelta
import asyncio
from typing import Optional

class ModerationCog(commands.Cog):
    """Moderasyon komutları"""
    
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="kick", description="Kullanıcıyı sunucudan atar")
    @app_commands.describe(
        kullanici="Atılacak kullanıcı",
        sebep="Atma sebebi"
    )
    async def kick(self, interaction: discord.Interaction, kullanici: discord.Member, sebep: str = "Belirtilmedi"):
        """Kullanıcıyı sunucudan atar"""
        
        # Yetki kontrolü
        if not interaction.user.guild_permissions.kick_members:
            embed = discord.Embed(
                title="❌ Yetki Hatası",
                description="Bu komutu kullanmak için 'Üyeleri At' yetkisine sahip olmalısınız.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Bot yetki kontrolü
        if not interaction.guild.me.guild_permissions.kick_members:
            embed = discord.Embed(
                title="❌ Bot Yetki Hatası",
                description="Bu komutu kullanmak için botun 'Üyeleri At' yetkisine sahip olması gerekiyor.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Kendini atamaz
        if kullanici.id == interaction.user.id:
            embed = discord.Embed(
                title="❌ Hata",
                description="Kendinizi atamazsınız!",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Botu atamaz
        if kullanici.id == self.bot.user.id:
            embed = discord.Embed(
                title="❌ Hata",
                description="Beni atamazsınız!",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Rol hiyerarşisi kontrolü
        if kullanici.top_role >= interaction.user.top_role:
            embed = discord.Embed(
                title="❌ Yetki Hatası",
                description="Bu kullanıcı sizden üst veya eşit yetkiye sahip!",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            # Kullanıcıya özel mesaj gönder
            try:
                dm_embed = discord.Embed(
                    title="🚫 Sunucudan Atıldınız",
                    description=f"**Sunucu:** {interaction.guild.name}\n**Sebep:** {sebep}\n**Moderatör:** {interaction.user.mention}",
                    color=discord.Color.orange()
                )
                await kullanici.send(embed=dm_embed)
            except:
                pass
            
            # Kullanıcıyı at
            await kullanici.kick(reason=f"{interaction.user} tarafından: {sebep}")
            
            # Başarı mesajı
            embed = discord.Embed(
                title="✅ Kullanıcı Atıldı",
                description=f"**Kullanıcı:** {kullanici.mention}\n**Sebep:** {sebep}\n**Moderatör:** {interaction.user.mention}",
                color=discord.Color.green()
            )
            await interaction.response.send_message(embed=embed)
            
            # Moderasyon kaydı ekle
            await self.bot.db.add_mod_log(
                interaction.guild.id,
                kullanici.id,
                interaction.user.id,
                "kick",
                sebep
            )
            
        except Exception as e:
            embed = discord.Embed(
                title="❌ Hata",
                description=f"Kullanıcı atılırken bir hata oluştu: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="ban", description="Kullanıcıyı sunucudan yasaklar")
    @app_commands.describe(
        kullanici="Yasaklanacak kullanıcı",
        sebep="Yasaklama sebebi",
        mesaj_sil="Silinecek mesaj gün sayısı (0-7)"
    )
    async def ban(self, interaction: discord.Interaction, kullanici: discord.Member, sebep: str = "Belirtilmedi", mesaj_sil: int = 0):
        """Kullanıcıyı sunucudan yasaklar"""
        
        # Yetki kontrolü
        if not interaction.user.guild_permissions.ban_members:
            embed = discord.Embed(
                title="❌ Yetki Hatası",
                description="Bu komutu kullanmak için 'Üyeleri Yasakla' yetkisine sahip olmalısınız.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Bot yetki kontrolü
        if not interaction.guild.me.guild_permissions.ban_members:
            embed = discord.Embed(
                title="❌ Bot Yetki Hatası",
                description="Bu komutu kullanmak için botun 'Üyeleri Yasakla' yetkisine sahip olması gerekiyor.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Mesaj silme gün sayısı kontrolü
        if mesaj_sil < 0 or mesaj_sil > 7:
            embed = discord.Embed(
                title="❌ Hata",
                description="Mesaj silme gün sayısı 0-7 arasında olmalıdır!",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Kendini yasaklayamaz
        if kullanici.id == interaction.user.id:
            embed = discord.Embed(
                title="❌ Hata",
                description="Kendinizi yasaklayamazsınız!",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Botu yasaklayamaz
        if kullanici.id == self.bot.user.id:
            embed = discord.Embed(
                title="❌ Hata",
                description="Beni yasaklayamazsınız!",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Rol hiyerarşisi kontrolü
        if kullanici.top_role >= interaction.user.top_role:
            embed = discord.Embed(
                title="❌ Yetki Hatası",
                description="Bu kullanıcı sizden üst veya eşit yetkiye sahip!",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            # Kullanıcıya özel mesaj gönder
            try:
                dm_embed = discord.Embed(
                    title="🔨 Sunucudan Yasaklandınız",
                    description=f"**Sunucu:** {interaction.guild.name}\n**Sebep:** {sebep}\n**Moderatör:** {interaction.user.mention}",
                    color=discord.Color.red()
                )
                await kullanici.send(embed=dm_embed)
            except:
                pass
            
            # Kullanıcıyı yasakla
            await kullanici.ban(reason=f"{interaction.user} tarafından: {sebep}", delete_message_days=mesaj_sil)
            
            # Başarı mesajı
            embed = discord.Embed(
                title="🔨 Kullanıcı Yasaklandı",
                description=f"**Kullanıcı:** {kullanici.mention}\n**Sebep:** {sebep}\n**Moderatör:** {interaction.user.mention}",
                color=discord.Color.red()
            )
            if mesaj_sil > 0:
                embed.add_field(name="📝 Mesaj Silme", value=f"Son {mesaj_sil} günün mesajları silindi", inline=False)
            
            await interaction.response.send_message(embed=embed)
            
            # Moderasyon kaydı ekle
            await self.bot.db.add_mod_log(
                interaction.guild.id,
                kullanici.id,
                interaction.user.id,
                "ban",
                sebep
            )
            
        except Exception as e:
            embed = discord.Embed(
                title="❌ Hata",
                description=f"Kullanıcı yasaklanırken bir hata oluştu: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="unban", description="Kullanıcının yasağını kaldırır")
    @app_commands.describe(
        kullanici_id="Yasağı kaldırılacak kullanıcının ID'si",
        sebep="Yasak kaldırma sebebi"
    )
    async def unban(self, interaction: discord.Interaction, kullanici_id: str, sebep: str = "Belirtilmedi"):
        """Kullanıcının yasağını kaldırır"""
        
        # Yetki kontrolü
        if not interaction.user.guild_permissions.ban_members:
            embed = discord.Embed(
                title="❌ Yetki Hatası",
                description="Bu komutu kullanmak için 'Üyeleri Yasakla' yetkisine sahip olmalısınız.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            user_id = int(kullanici_id)
        except ValueError:
            embed = discord.Embed(
                title="❌ Hata",
                description="Geçersiz kullanıcı ID'si!",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            # Yasaklı kullanıcıları kontrol et
            banned_users = [entry async for entry in interaction.guild.bans()]
            banned_user = None
            
            for ban_entry in banned_users:
                if ban_entry.user.id == user_id:
                    banned_user = ban_entry.user
                    break
            
            if not banned_user:
                embed = discord.Embed(
                    title="❌ Hata",
                    description="Bu kullanıcı yasaklı değil!",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            # Yasağı kaldır
            await interaction.guild.unban(banned_user, reason=f"{interaction.user} tarafından: {sebep}")
            
            # Başarı mesajı
            embed = discord.Embed(
                title="✅ Yasak Kaldırıldı",
                description=f"**Kullanıcı:** {banned_user.mention}\n**Sebep:** {sebep}\n**Moderatör:** {interaction.user.mention}",
                color=discord.Color.green()
            )
            await interaction.response.send_message(embed=embed)
            
            # Moderasyon kaydı ekle
            await self.bot.db.add_mod_log(
                interaction.guild.id,
                banned_user.id,
                interaction.user.id,
                "unban",
                sebep
            )
            
        except Exception as e:
            embed = discord.Embed(
                title="❌ Hata",
                description=f"Yasak kaldırılırken bir hata oluştu: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="uyar", description="Kullanıcıya uyarı verir")
    @app_commands.describe(
        kullanici="Uyarılacak kullanıcı",
        sebep="Uyarı sebebi"
    )
    async def warn(self, interaction: discord.Interaction, kullanici: discord.Member, sebep: str):
        """Kullanıcıya uyarı verir"""
        
        # Yetki kontrolü
        if not interaction.user.guild_permissions.manage_messages:
            embed = discord.Embed(
                title="❌ Yetki Hatası",
                description="Bu komutu kullanmak için 'Mesajları Yönet' yetkisine sahip olmalısınız.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Kendini uyaramaz
        if kullanici.id == interaction.user.id:
            embed = discord.Embed(
                title="❌ Hata",
                description="Kendinizi uyaramazsınız!",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            # Uyarı ekle
            await self.bot.db.add_warning(
                interaction.guild.id,
                kullanici.id,
                interaction.user.id,
                sebep
            )
            
            # Toplam uyarı sayısını al
            warnings = await self.bot.db.get_warnings(interaction.guild.id, kullanici.id)
            warning_count = len(warnings)
            
            # Kullanıcıya özel mesaj gönder
            try:
                dm_embed = discord.Embed(
                    title="⚠️ Uyarı Aldınız",
                    description=f"**Sunucu:** {interaction.guild.name}\n**Sebep:** {sebep}\n**Moderatör:** {interaction.user.mention}\n**Toplam Uyarı:** {warning_count}",
                    color=discord.Color.orange()
                )
                await kullanici.send(embed=dm_embed)
            except:
                pass
            
            # Başarı mesajı
            embed = discord.Embed(
                title="⚠️ Uyarı Verildi",
                description=f"**Kullanıcı:** {kullanici.mention}\n**Sebep:** {sebep}\n**Moderatör:** {interaction.user.mention}\n**Toplam Uyarı:** {warning_count}",
                color=discord.Color.orange()
            )
            
            # Otomatik işlem kontrolü
            if warning_count >= 5:
                embed.add_field(name="🚨 Kritik Uyarı", value="Bu kullanıcı 5 veya daha fazla uyarıya sahip!", inline=False)
            elif warning_count >= 3:
                embed.add_field(name="⚠️ Dikkat", value="Bu kullanıcı 3 veya daha fazla uyarıya sahip!", inline=False)
            
            await interaction.response.send_message(embed=embed)
            
            # Moderasyon kaydı ekle
            await self.bot.db.add_mod_log(
                interaction.guild.id,
                kullanici.id,
                interaction.user.id,
                "warn",
                sebep
            )
            
        except Exception as e:
            embed = discord.Embed(
                title="❌ Hata",
                description=f"Uyarı verilirken bir hata oluştu: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="timeout", description="Kullanıcıyı belirtilen süre susturur")
    @app_commands.describe(
        kullanici="Susturulacak kullanıcı",
        süre="Susturma süresi (dakika)",
        sebep="Susturma sebebi"
    )
    async def timeout(self, interaction: discord.Interaction, kullanici: discord.Member, süre: int, sebep: str = "Belirtilmedi"):
        """Kullanıcıyı belirtilen süre susturur"""
        
        # Yetki kontrolü
        if not interaction.user.guild_permissions.moderate_members:
            embed = discord.Embed(
                title="❌ Yetki Hatası",
                description="Bu komutu kullanmak için 'Üyeleri Zaman Aşımına Uğrat' yetkisine sahip olmalısınız.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Süre kontrolü (1 dakika - 28 gün)
        if süre < 1 or süre > 40320:  # 28 gün = 40320 dakika
            embed = discord.Embed(
                title="❌ Hata",
                description="Susturma süresi 1 dakika ile 28 gün arasında olmalıdır!",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Kendini susturamaz
        if kullanici.id == interaction.user.id:
            embed = discord.Embed(
                title="❌ Hata",
                description="Kendinizi susturamassınız!",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Rol hiyerarşisi kontrolü
        if kullanici.top_role >= interaction.user.top_role:
            embed = discord.Embed(
                title="❌ Yetki Hatası",
                description="Bu kullanıcı sizden üst veya eşit yetkiye sahip!",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            # Susturma süresini hesapla
            timeout_until = datetime.now() + timedelta(minutes=süre)
            
            # Kullanıcıyı sustur
            await kullanici.timeout(timeout_until, reason=f"{interaction.user} tarafından: {sebep}")
            
            # Kullanıcıya özel mesaj gönder
            try:
                dm_embed = discord.Embed(
                    title="🔇 Susturuldunuz",
                    description=f"**Sunucu:** {interaction.guild.name}\n**Süre:** {süre} dakika\n**Sebep:** {sebep}\n**Moderatör:** {interaction.user.mention}",
                    color=discord.Color.orange()
                )
                await kullanici.send(embed=dm_embed)
            except:
                pass
            
            # Başarı mesajı
            embed = discord.Embed(
                title="🔇 Kullanıcı Susturuldu",
                description=f"**Kullanıcı:** {kullanici.mention}\n**Süre:** {süre} dakika\n**Sebep:** {sebep}\n**Moderatör:** {interaction.user.mention}",
                color=discord.Color.orange()
            )
            embed.add_field(name="⏰ Susturma Bitiş", value=f"<t:{int(timeout_until.timestamp())}:F>", inline=False)
            
            await interaction.response.send_message(embed=embed)
            
            # Moderasyon kaydı ekle
            await self.bot.db.add_mod_log(
                interaction.guild.id,
                kullanici.id,
                interaction.user.id,
                "timeout",
                sebep,
                süre
            )
            
        except Exception as e:
            embed = discord.Embed(
                title="❌ Hata",
                description=f"Kullanıcı susturulurken bir hata oluştu: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="uyarilar", description="Kullanıcının uyarılarını gösterir")
    @app_commands.describe(kullanici="Uyarıları görüntülenecek kullanıcı")
    async def warnings(self, interaction: discord.Interaction, kullanici: discord.Member):
        """Kullanıcının uyarılarını gösterir"""
        
        # Yetki kontrolü
        if not interaction.user.guild_permissions.manage_messages:
            embed = discord.Embed(
                title="❌ Yetki Hatası",
                description="Bu komutu kullanmak için 'Mesajları Yönet' yetkisine sahip olmalısınız.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            warnings = await self.bot.db.get_warnings(interaction.guild.id, kullanici.id)
            
            if not warnings:
                embed = discord.Embed(
                    title="✅ Temiz Kayıt",
                    description=f"{kullanici.mention} kullanıcısının hiç uyarısı bulunmuyor.",
                    color=discord.Color.green()
                )
                await interaction.response.send_message(embed=embed)
                return
            
            embed = discord.Embed(
                title=f"⚠️ {kullanici.display_name} Uyarıları",
                description=f"**Toplam Uyarı:** {len(warnings)}",
                color=discord.Color.orange()
            )
            
            for i, warning in enumerate(warnings[:10], 1):  # Son 10 uyarıyı göster
                # Moderatör bilgisini al
                moderator = self.bot.get_user(warning[3])
                moderator_name = moderator.display_name if moderator else "Bilinmeyen"
                
                # Tarih formatla
                created_at = datetime.fromisoformat(warning[5])
                
                embed.add_field(
                    name=f"Uyarı #{i}",
                    value=f"**Sebep:** {warning[4]}\n**Moderatör:** {moderator_name}\n**Tarih:** <t:{int(created_at.timestamp())}:R>",
                    inline=False
                )
            
            if len(warnings) > 10:
                embed.set_footer(text=f"Sadece son 10 uyarı gösteriliyor. Toplam: {len(warnings)}")
            
            await interaction.response.send_message(embed=embed)
            
        except Exception as e:
            embed = discord.Embed(
                title="❌ Hata",
                description=f"Uyarılar getirilirken bir hata oluştu: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)

async def setup(bot):
    await bot.add_cog(ModerationCog(bot))

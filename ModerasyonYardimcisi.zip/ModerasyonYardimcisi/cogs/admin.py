import discord
from discord.ext import commands
from discord import app_commands
from typing import Optional

class AdminCog(commands.Cog):
    """Yönetici komutları"""
    
    def __init__(self, bot):
        self.bot = bot
    
    @app_commands.command(name="ayarlar", description="Sunucu ayarlarını gösterir")
    async def settings(self, interaction: discord.Interaction):
        """Sunucu ayarlarını gösterir"""
        
        # Yetki kontrolü
        if not interaction.user.guild_permissions.manage_guild:
            embed = discord.Embed(
                title="❌ Yetki Hatası",
                description="Bu komutu kullanmak için 'Sunucuyu Yönet' yetkisine sahip olmalısınız.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            settings = await self.bot.db.get_guild_settings(interaction.guild.id)
            
            embed = discord.Embed(
                title="⚙️ Sunucu Ayarları",
                description=f"**Sunucu:** {interaction.guild.name}",
                color=discord.Color.blue()
            )
            
            # Temel ayarlar
            prefix = settings.get('prefix', '!') if settings else '!'
            language = settings.get('language', 'tr') if settings else 'tr'
            
            embed.add_field(name="Prefix", value=f"`{prefix}`", inline=True)
            embed.add_field(name="Dil", value=language, inline=True)
            embed.add_field(name="Bot ID", value=self.bot.user.id, inline=True)
            
            # Kanal ayarları
            welcome_channel = None
            goodbye_channel = None
            log_channel = None
            
            if settings:
                if settings.get('welcome_channel'):
                    welcome_channel = self.bot.get_channel(settings['welcome_channel'])
                if settings.get('goodbye_channel'):
                    goodbye_channel = self.bot.get_channel(settings['goodbye_channel'])
                if settings.get('log_channel'):
                    log_channel = self.bot.get_channel(settings['log_channel'])
            
            embed.add_field(
                name="Hoşgeldin Kanalı", 
                value=welcome_channel.mention if welcome_channel else "Ayarlanmamış", 
                inline=True
            )
            embed.add_field(
                name="Veda Kanalı", 
                value=goodbye_channel.mention if goodbye_channel else "Ayarlanmamış", 
                inline=True
            )
            embed.add_field(
                name="Log Kanalı", 
                value=log_channel.mention if log_channel else "Ayarlanmamış", 
                inline=True
            )
            
            # Sistem ayarları
            autorole_enabled = settings.get('autorole_enabled', 0) if settings else 0
            word_filter_enabled = settings.get('word_filter_enabled', 1) if settings else 1
            spam_protection_enabled = settings.get('spam_protection_enabled', 1) if settings else 1
            anti_raid_enabled = settings.get('anti_raid_enabled', 1) if settings else 1
            
            embed.add_field(
                name="Otomatik Rol", 
                value="✅ Aktif" if autorole_enabled else "❌ Pasif", 
                inline=True
            )
            embed.add_field(
                name="Kelime Filtresi", 
                value="✅ Aktif" if word_filter_enabled else "❌ Pasif", 
                inline=True
            )
            embed.add_field(
                name="Spam Koruması", 
                value="✅ Aktif" if spam_protection_enabled else "❌ Pasif", 
                inline=True
            )
            embed.add_field(
                name="Anti-Raid", 
                value="✅ Aktif" if anti_raid_enabled else "❌ Pasif", 
                inline=True
            )
            
            # İstatistikler
            auto_roles = await self.bot.db.get_auto_roles(interaction.guild.id)
            banned_words = await self.bot.db.get_banned_words(interaction.guild.id)
            
            embed.add_field(name="Otomatik Rol Sayısı", value=len(auto_roles), inline=True)
            embed.add_field(name="Yasaklı Kelime Sayısı", value=len(banned_words), inline=True)
            
            embed.set_footer(text=f"Sunucu ID: {interaction.guild.id}")
            
            await interaction.response.send_message(embed=embed)
            
        except Exception as e:
            embed = discord.Embed(
                title="❌ Hata",
                description=f"Ayarlar yüklenirken bir hata oluştu: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="prefix", description="Bot prefixini değiştirir")
    @app_commands.describe(yeni_prefix="Yeni prefix (1-5 karakter)")
    async def set_prefix(self, interaction: discord.Interaction, yeni_prefix: str):
        """Bot prefixini değiştirir"""
        
        # Yetki kontrolü
        if not interaction.user.guild_permissions.manage_guild:
            embed = discord.Embed(
                title="❌ Yetki Hatası",
                description="Bu komutu kullanmak için 'Sunucuyu Yönet' yetkisine sahip olmalısınız.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Prefix uzunluk kontrolü
        if len(yeni_prefix) < 1 or len(yeni_prefix) > 5:
            embed = discord.Embed(
                title="❌ Hata",
                description="Prefix 1-5 karakter arasında olmalıdır!",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            # Sunucu ayarlarını güncelle
            await self.bot.db.update_guild_setting(interaction.guild.id, 'prefix', yeni_prefix)
            
            embed = discord.Embed(
                title="✅ Prefix Değiştirildi",
                description=f"Yeni prefix: `{yeni_prefix}`\n\nSlash komutları (/) her zaman kullanılabilir.",
                color=discord.Color.green()
            )
            await interaction.response.send_message(embed=embed)
            
        except Exception as e:
            embed = discord.Embed(
                title="❌ Hata",
                description=f"Prefix değiştirilirken bir hata oluştu: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="kelime-filtresi", description="Kelime filtresini yönetir")
    @app_commands.describe(
        işlem="Yapılacak işlem",
        kelime="Eklenecek/silinecek kelime",
        şiddet="Ceza şiddeti (1: Uyarı, 2: Susturma, 3: Atma)"
    )
    @app_commands.choices(işlem=[
        app_commands.Choice(name="Ekle", value="add"),
        app_commands.Choice(name="Sil", value="remove"),
        app_commands.Choice(name="Liste", value="list"),
        app_commands.Choice(name="Aç/Kapat", value="toggle")
    ])
    async def word_filter(self, interaction: discord.Interaction, işlem: str, kelime: str = None, şiddet: int = 1):
        """Kelime filtresini yönetir"""
        
        # Yetki kontrolü
        if not interaction.user.guild_permissions.manage_messages:
            embed = discord.Embed(
                title="❌ Yetki Hatası",
                description="Bu komutu kullanmak için 'Mesajları Yönet' yetkisine sahip olmalısınız.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            if işlem == "add":
                if not kelime:
                    embed = discord.Embed(
                        title="❌ Hata",
                        description="Eklenecek kelimeyi belirtmelisiniz!",
                        color=discord.Color.red()
                    )
                    await interaction.response.send_message(embed=embed, ephemeral=True)
                    return
                
                if şiddet < 1 or şiddet > 3:
                    embed = discord.Embed(
                        title="❌ Hata",
                        description="Şiddet seviyesi 1-3 arasında olmalıdır!",
                        color=discord.Color.red()
                    )
                    await interaction.response.send_message(embed=embed, ephemeral=True)
                    return
                
                await self.bot.db.add_banned_word(interaction.guild.id, kelime, şiddet)
                
                şiddet_text = ["", "Uyarı", "Susturma", "Atma"][şiddet]
                embed = discord.Embed(
                    title="✅ Kelime Eklendi",
                    description=f"**Kelime:** {kelime}\n**Ceza:** {şiddet_text}",
                    color=discord.Color.green()
                )
                await interaction.response.send_message(embed=embed)
                
            elif işlem == "remove":
                if not kelime:
                    embed = discord.Embed(
                        title="❌ Hata",
                        description="Silinecek kelimeyi belirtmelisiniz!",
                        color=discord.Color.red()
                    )
                    await interaction.response.send_message(embed=embed, ephemeral=True)
                    return
                
                await self.bot.db.remove_banned_word(interaction.guild.id, kelime)
                
                embed = discord.Embed(
                    title="✅ Kelime Silindi",
                    description=f"**Kelime:** {kelime}",
                    color=discord.Color.green()
                )
                await interaction.response.send_message(embed=embed)
                
            elif işlem == "list":
                banned_words = await self.bot.db.get_banned_words(interaction.guild.id)
                
                if not banned_words:
                    embed = discord.Embed(
                        title="📋 Yasaklı Kelimeler",
                        description="Hiç yasaklı kelime tanımlanmamış.",
                        color=discord.Color.blue()
                    )
                    await interaction.response.send_message(embed=embed)
                    return
                
                embed = discord.Embed(
                    title="📋 Yasaklı Kelimeler",
                    description=f"Toplam {len(banned_words)} yasaklı kelime",
                    color=discord.Color.blue()
                )
                
                word_list = []
                for word, severity in banned_words:
                    şiddet_text = ["", "Uyarı", "Susturma", "Atma"][severity]
                    word_list.append(f"• {word} ({şiddet_text})")
                
                # Kelime listesini 20'şer ayır
                for i in range(0, len(word_list), 20):
                    chunk = word_list[i:i+20]
                    embed.add_field(
                        name=f"Kelimeler ({i+1}-{min(i+20, len(word_list))})",
                        value="\n".join(chunk),
                        inline=False
                    )
                
                await interaction.response.send_message(embed=embed)
                
            elif işlem == "toggle":
                settings = await self.bot.db.get_guild_settings(interaction.guild.id)
                current_status = settings.get('word_filter_enabled', 1) if settings else 1
                new_status = 0 if current_status else 1
                
                await self.bot.db.update_guild_setting(interaction.guild.id, 'word_filter_enabled', new_status)
                
                status_text = "Etkinleştirildi" if new_status else "Devre Dışı Bırakıldı"
                embed = discord.Embed(
                    title="✅ Kelime Filtresi",
                    description=f"Kelime filtresi {status_text}.",
                    color=discord.Color.green()
                )
                await interaction.response.send_message(embed=embed)
                
        except Exception as e:
            embed = discord.Embed(
                title="❌ Hata",
                description=f"Kelime filtresi yönetilirken bir hata oluştu: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="spam-koruması", description="Spam korumasını aç/kapat")
    async def spam_protection(self, interaction: discord.Interaction):
        """Spam korumasını aç/kapat"""
        
        # Yetki kontrolü
        if not interaction.user.guild_permissions.manage_messages:
            embed = discord.Embed(
                title="❌ Yetki Hatası",
                description="Bu komutu kullanmak için 'Mesajları Yönet' yetkisine sahip olmalısınız.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            settings = await self.bot.db.get_guild_settings(interaction.guild.id)
            current_status = settings.get('spam_protection_enabled', 1) if settings else 1
            new_status = 0 if current_status else 1
            
            await self.bot.db.update_guild_setting(interaction.guild.id, 'spam_protection_enabled', new_status)
            
            status_text = "Etkinleştirildi" if new_status else "Devre Dışı Bırakıldı"
            embed = discord.Embed(
                title="✅ Spam Koruması",
                description=f"Spam koruması {status_text}.",
                color=discord.Color.green()
            )
            await interaction.response.send_message(embed=embed)
            
        except Exception as e:
            embed = discord.Embed(
                title="❌ Hata",
                description=f"Spam koruması ayarlanırken bir hata oluştu: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="anti-raid", description="Anti-raid korumasını aç/kapat")
    async def anti_raid(self, interaction: discord.Interaction):
        """Anti-raid korumasını aç/kapat"""
        
        # Yetki kontrolü
        if not interaction.user.guild_permissions.manage_guild:
            embed = discord.Embed(
                title="❌ Yetki Hatası",
                description="Bu komutu kullanmak için 'Sunucuyu Yönet' yetkisine sahip olmalısınız.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            settings = await self.bot.db.get_guild_settings(interaction.guild.id)
            current_status = settings.get('anti_raid_enabled', 1) if settings else 1
            new_status = 0 if current_status else 1
            
            await self.bot.db.update_guild_setting(interaction.guild.id, 'anti_raid_enabled', new_status)
            
            status_text = "Etkinleştirildi" if new_status else "Devre Dışı Bırakıldı"
            embed = discord.Embed(
                title="✅ Anti-Raid",
                description=f"Anti-raid koruması {status_text}.",
                color=discord.Color.green()
            )
            await interaction.response.send_message(embed=embed)
            
        except Exception as e:
            embed = discord.Embed(
                title="❌ Hata",
                description=f"Anti-raid koruması ayarlanırken bir hata oluştu: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @app_commands.command(name="temizle", description="Belirtilen sayıda mesaj siler")
    @app_commands.describe(
        sayı="Silinecek mesaj sayısı (1-100)",
        kullanıcı="Belirli bir kullanıcının mesajlarını sil"
    )
    async def clear(self, interaction: discord.Interaction, sayı: int, kullanıcı: Optional[discord.Member] = None):
        """Belirtilen sayıda mesaj siler"""
        
        # Yetki kontrolü
        if not interaction.user.guild_permissions.manage_messages:
            embed = discord.Embed(
                title="❌ Yetki Hatası",
                description="Bu komutu kullanmak için 'Mesajları Yönet' yetkisine sahip olmalısınız.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        # Sayı kontrolü
        if sayı < 1 or sayı > 100:
            embed = discord.Embed(
                title="❌ Hata",
                description="Silinecek mesaj sayısı 1-100 arasında olmalıdır!",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        try:
            # Geçici yanıt
            await interaction.response.defer()
            
            # Mesajları sil
            if kullanıcı:
                def check(m):
                    return m.author == kullanıcı
                deleted = await interaction.channel.purge(limit=sayı, check=check)
            else:
                deleted = await interaction.channel.purge(limit=sayı)
            
            embed = discord.Embed(
                title="✅ Mesajlar Silindi",
                description=f"**Silinen Mesaj:** {len(deleted)}\n**Kanal:** {interaction.channel.mention}",
                color=discord.Color.green()
            )
            
            if kullanıcı:
                embed.add_field(name="Kullanıcı", value=kullanıcı.mention, inline=True)
            
            # Geçici mesaj gönder
            await interaction.followup.send(embed=embed, ephemeral=True)
            
        except Exception as e:
            embed = discord.Embed(
                title="❌ Hata",
                description=f"Mesajlar silinirken bir hata oluştu: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.followup.send(embed=embed, ephemeral=True)
    


async def setup(bot):
    await bot.add_cog(AdminCog(bot))

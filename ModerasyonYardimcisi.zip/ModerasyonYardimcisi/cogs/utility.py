import discord
from discord import app_commands
from discord.ext import commands
import time
import psutil
from typing import Optional

class UtilityCog(commands.Cog):
    """Yardımcı komutlar"""
    
    def __init__(self, bot):
        self.bot = bot
        self.start_time = time.time()
    
    @app_commands.command(name="yardım", description="Bot komutlarını ve kullanım bilgilerini gösterir")
    async def help(self, interaction: discord.Interaction):
        """Yardım menüsü"""
        
        embed = discord.Embed(
            title="🤖 Türkçe Moderasyon Botu",
            description="Sunucunuzu güvende tutmak için tasarlanmış kapsamlı moderasyon botu",
            color=discord.Color.blue()
        )
        
        embed.add_field(
            name="🔐 Moderasyon Komutları",
            value="• `/kick` - Kullanıcıyı sunucudan atar\n"
                  "• `/ban` - Kullanıcıyı yasaklar\n"
                  "• `/unban` - Yasağı kaldırır\n"
                  "• `/uyar` - Kullanıcıya uyarı verir\n"
                  "• `/timeout` - Kullanıcıyı susturur\n"
                  "• `/uyarilar` - Kullanıcı uyarılarını gösterir",
            inline=False
        )
        
        embed.add_field(
            name="🎭 Otomatik Rol Sistemi",
            value="• `/otorol-ekle` - Otomatik rol ekler\n"
                  "• `/otorol-sil` - Otomatik rol siler\n"
                  "• `/otorol-liste` - Otomatik rolleri listeler",
            inline=False
        )
        
        embed.add_field(
            name="⚙️ Yönetim Komutları",
            value="• `/ayarlar` - Sunucu ayarlarını gösterir\n"
                  "• `/prefix` - Bot prefixini değiştirir\n"
                  "• `/kelime-filtresi` - Kelime filtresini yönetir\n"
                  "• `/spam-koruması` - Spam korumasını aç/kapat\n"
                  "• `/anti-raid` - Anti-raid korumasını aç/kapat\n"
                  "• `/temizle` - Mesajları toplu siler",
            inline=False
        )
        
        embed.add_field(
            name="📊 Log ve Mesaj Sistemi",
            value="• `/log-kanal` - Log kanalını ayarlar\n"
                  "• `/hosgeldin-ayarla` - Hoşgeldin sistemini ayarlar\n"
                  "• `/veda-ayarla` - Veda sistemini ayarlar",
            inline=False
        )
        
        embed.add_field(
            name="🔧 Yardımcı Komutları",
            value="• `/kullanıcı-bilgi` - Kullanıcı bilgilerini gösterir\n"
                  "• `/sunucu-bilgi` - Sunucu bilgilerini gösterir\n"
                  "• `/bot-bilgi` - Bot istatistiklerini gösterir\n"
                  "• `/ping` - Bot gecikme süresini gösterir",
            inline=False
        )
        
        embed.add_field(
            name="📋 Önemli Notlar",
            value="• Komutlar `/` ile başlar (slash commands)\n"
                  "• Moderasyon komutları için uygun yetkilere sahip olmalısınız\n"
                  "• Bot sürekli güncellenmekte ve geliştirilmektedir",
            inline=False
        )
        
        embed.set_footer(text="Daha fazla bilgi için sunucu yöneticilerinizle iletişime geçin")
        embed.set_thumbnail(url=self.bot.user.display_avatar.url)
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="kullanıcı-bilgi", description="Kullanıcı hakkında detaylı bilgi gösterir")
    @app_commands.describe(kullanıcı="Bilgileri görüntülenecek kullanıcı")
    async def user_info(self, interaction: discord.Interaction, kullanıcı: Optional[discord.Member] = None):
        """Kullanıcı bilgilerini gösterir"""
        
        # Kullanıcı belirtilmemişse komutu kullananı al
        if kullanıcı is None:
            if not isinstance(interaction.user, discord.Member):
                embed = discord.Embed(
                    title="❌ Hata",
                    description="Bu komut sadece sunucularda kullanılabilir.",
                    color=discord.Color.red()
                )
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            kullanıcı = interaction.user
        
        embed = discord.Embed(
            title=f"👤 {kullanıcı.display_name}",
            color=kullanıcı.color if kullanıcı.color != discord.Color.default() else discord.Color.blue()
        )
        
        embed.set_thumbnail(url=kullanıcı.display_avatar.url)
        
        # Temel bilgiler
        embed.add_field(name="Kullanıcı Adı", value=f"{kullanıcı.name}#{kullanıcı.discriminator}", inline=True)
        embed.add_field(name="ID", value=kullanıcı.id, inline=True)
        embed.add_field(name="Takma Ad", value=kullanıcı.nick or "Yok", inline=True)
        
        # Tarihler
        created_at = kullanıcı.created_at.strftime("%d.%m.%Y %H:%M")
        embed.add_field(name="Hesap Oluşturma", value=created_at, inline=True)
        
        if kullanıcı.joined_at:
            joined_at = kullanıcı.joined_at.strftime("%d.%m.%Y %H:%M")
            embed.add_field(name="Sunucuya Katılma", value=joined_at, inline=True)
        
        # Bot kontrolü
        embed.add_field(name="Bot mu?", value="Evet" if kullanıcı.bot else "Hayır", inline=True)
        
        # Roller
        if len(kullanıcı.roles) > 1:
            roles = [role.mention for role in kullanıcı.roles[1:]]  # @everyone rolünü hariç tut
            roles_text = ", ".join(roles[:10])  # İlk 10 rolü göster
            if len(kullanıcı.roles) > 11:
                roles_text += f" ve {len(kullanıcı.roles) - 11} tane daha..."
            embed.add_field(name="Roller", value=roles_text, inline=False)
        
        # En yüksek rol
        if kullanıcı.top_role != kullanıcı.guild.default_role:
            embed.add_field(name="En Yüksek Rol", value=kullanıcı.top_role.mention, inline=True)
        
        # Ses durumu
        if kullanıcı.voice:
            voice_channel = kullanıcı.voice.channel.mention if kullanıcı.voice.channel else "Bilinmiyor"
            embed.add_field(name="Ses Kanalı", value=voice_channel, inline=True)
        else:
            embed.add_field(name="Ses Durumu", value="Çevrimdışı", inline=True)
        
        # Uyarı sayısı (yetkili kullanıcılar için)
        if isinstance(interaction.user, discord.Member) and interaction.user.guild_permissions.manage_messages:
            try:
                warnings = await self.bot.db.get_warnings(interaction.guild.id, kullanıcı.id)
                embed.add_field(name="Uyarı Sayısı", value=len(warnings), inline=True)
            except:
                pass
        
        embed.set_footer(text=f"Kullanıcı ID: {kullanıcı.id}")
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="bot-bilgi", description="Bot hakkında bilgi ve istatistikleri gösterir")
    async def show_bot_info(self, interaction: discord.Interaction):
        """Bot bilgilerini gösterir"""
        
        # Çalışma süresi hesapla
        uptime = int(time.time() - self.start_time)
        hours = uptime // 3600
        minutes = (uptime % 3600) // 60
        seconds = uptime % 60
        uptime_str = f"{hours}s {minutes}d {seconds}sn"
        
        embed = discord.Embed(
            title="🤖 Bot Bilgileri",
            description="Türkçe Moderasyon Bot - v1.0",
            color=discord.Color.blue()
        )
        
        # Bot istatistikleri
        embed.add_field(name="Sunucu Sayısı", value=len(self.bot.guilds), inline=True)
        embed.add_field(name="Kullanıcı Sayısı", value=len(self.bot.users), inline=True)
        embed.add_field(name="Çalışma Süresi", value=uptime_str, inline=True)
        
        # Sistem bilgileri
        memory_usage = psutil.virtual_memory().percent
        embed.add_field(name="Bellek Kullanımı", value=f"%{memory_usage:.1f}", inline=True)
        
        ping = round(self.bot.latency * 1000)
        embed.add_field(name="Ping", value=f"{ping}ms", inline=True)
        
        embed.add_field(name="Python Sürümü", value="3.11", inline=True)
        
        # Özellikler
        features = [
            "✅ Slash Commands",
            "✅ Moderasyon Sistemi",
            "✅ Otomatik Rol",
            "✅ Spam Koruması",
            "✅ Log Sistemi",
            "✅ Anti-Raid"
        ]
        embed.add_field(name="Özellikler", value="\n".join(features), inline=False)
        
        embed.set_thumbnail(url=self.bot.user.display_avatar.url)
        embed.set_footer(text="Türk Discord topluluğu için özel olarak geliştirildi")
        
        await interaction.response.send_message(embed=embed)
    
    @app_commands.command(name="ping", description="Bot gecikme süresini ve durumunu gösterir")
    async def ping(self, interaction: discord.Interaction):
        """Bot pingini gösterir"""
        
        embed = discord.Embed(
            title="🏓 Pong!",
            description="Bot gecikme bilgileri",
            color=discord.Color.blue()
        )
        
        # API Gecikmesi
        api_latency = round(self.bot.latency * 1000)
        embed.add_field(name="API Gecikmesi", value=f"{api_latency}ms", inline=True)
        
        # Mesaj gecikmesi için zaman al
        start_time = time.time()
        await interaction.response.defer()
        end_time = time.time()
        
        message_latency = round((end_time - start_time) * 1000)
        embed.add_field(name="Mesaj Gecikmesi", value=f"{message_latency}ms", inline=True)
        
        # Gecikme durumuna göre renk
        latency = round(self.bot.latency * 1000)
        if latency < 100:
            embed.color = discord.Color.green()
            status = "🟢 Mükemmel"
        elif latency < 200:
            embed.color = discord.Color.yellow()
            status = "🟡 İyi"
        else:
            embed.color = discord.Color.red()
            status = "🔴 Yavaş"
        
        embed.add_field(name="Durum", value=status, inline=True)
        
        await interaction.followup.send(embed=embed)
    
    @app_commands.command(name="sunucu-bilgi", description="Sunucu hakkında detaylı bilgi gösterir")
    async def server_info(self, interaction: discord.Interaction):
        """Sunucu bilgilerini gösterir"""
        
        guild = interaction.guild
        if not guild:
            embed = discord.Embed(
                title="❌ Hata",
                description="Bu komut sadece sunucularda kullanılabilir.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return
        
        embed = discord.Embed(
            title=f"🏰 {guild.name}",
            description=guild.description or "Açıklama yok",
            color=discord.Color.blue()
        )
        
        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)
        
        # Temel bilgiler
        embed.add_field(name="Sunucu ID", value=guild.id, inline=True)
        embed.add_field(name="Sahip", value=guild.owner.mention if guild.owner else "Bilinmiyor", inline=True)
        embed.add_field(name="Oluşturma Tarihi", value=guild.created_at.strftime("%d.%m.%Y"), inline=True)
        
        # Üye sayıları
        total_members = guild.member_count
        bots = len([m for m in guild.members if m.bot])
        humans = total_members - bots
        
        embed.add_field(name="Toplam Üye", value=total_members, inline=True)
        embed.add_field(name="İnsan", value=humans, inline=True)
        embed.add_field(name="Bot", value=bots, inline=True)
        
        # Kanal sayıları
        text_channels = len(guild.text_channels)
        voice_channels = len(guild.voice_channels)
        categories = len(guild.categories)
        
        embed.add_field(name="Metin Kanalları", value=text_channels, inline=True)
        embed.add_field(name="Ses Kanalları", value=voice_channels, inline=True)
        embed.add_field(name="Kategoriler", value=categories, inline=True)
        
        # Rol sayısı
        embed.add_field(name="Rol Sayısı", value=len(guild.roles), inline=True)
        
        # Boost bilgileri
        embed.add_field(name="Boost Seviyesi", value=guild.premium_tier, inline=True)
        embed.add_field(name="Boost Sayısı", value=guild.premium_subscription_count or 0, inline=True)
        
        embed.set_footer(text=f"Sunucu ID: {guild.id}")
        
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="davet", description="Bot davet linkini gösterir")
    async def invite(self, interaction: discord.Interaction):
        """Bot davet linkini gösterir"""
        
        embed = discord.Embed(
            title="🔗 Bot Davet Linki",
            description="Botu kendi sunucunuza eklemek için aşağıdaki linki kullanın:",
            color=discord.Color.blue()
        )
        
        # Gerekli izinleri hesapla
        permissions = discord.Permissions(
            kick_members=True,
            ban_members=True,
            manage_messages=True,
            manage_roles=True,
            manage_channels=True,
            view_audit_log=True,
            send_messages=True,
            embed_links=True,
            attach_files=True,
            read_message_history=True,
            add_reactions=True,
            use_slash_commands=True,
            moderate_members=True
        )
        
        invite_url = discord.utils.oauth_url(self.bot.user.id, permissions=permissions)
        
        embed.add_field(
            name="Davet Linki",
            value=f"[Botu Sunucuya Ekle]({invite_url})",
            inline=False
        )
        
        embed.add_field(
            name="Gerekli İzinler",
            value="• Üyeleri At\n• Üyeleri Yasakla\n• Mesajları Yönet\n• Rolleri Yönet\n• Kanalları Yönet\n• Denetim Günlüğünü Görüntüle\n• Mesaj Gönder\n• Bağlantı Ekle\n• Dosya Ekle\n• Mesaj Geçmişini Oku\n• Reaksiyon Ekle\n• Slash Komutları Kullan\n• Üyeleri Zaman Aşımına Uğrat",
            inline=False
        )
        
        embed.set_footer(text="Bot eklendikten sonra /yardım komutunu kullanarak başlayabilirsiniz")
        
        await interaction.response.send_message(embed=embed)

async def setup(bot):
    await bot.add_cog(UtilityCog(bot))
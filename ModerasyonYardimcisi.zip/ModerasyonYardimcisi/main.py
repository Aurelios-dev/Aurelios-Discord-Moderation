import asyncio
import os
from bot import TurkishModerationBot

async def main():
    """Ana bot başlatma fonksiyonu"""
    # Discord bot token'ını environment variable'dan al
    token = os.getenv("DISCORD_BOT_TOKEN", "your_bot_token_here")
    
    if token == "your_bot_token_here":
        print("❌ DISCORD_BOT_TOKEN environment variable bulunamadı!")
        print("Lütfen bot token'ınızı DISCORD_BOT_TOKEN environment variable olarak ayarlayın.")
        return
    
    # Bot instance'ı oluştur
    bot = TurkishModerationBot()
    
    try:
        # Botu başlat
        await bot.start(token)
    except KeyboardInterrupt:
        print("\n🔄 Bot kapatılıyor...")
        await bot.close()
    except Exception as e:
        print(f"❌ Bot başlatılırken hata oluştu: {e}")

if __name__ == "__main__":
    asyncio.run(main())

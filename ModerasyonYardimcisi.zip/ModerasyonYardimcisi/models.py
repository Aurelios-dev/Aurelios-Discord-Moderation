from dataclasses import dataclass
from datetime import datetime
from typing import Optional, List

@dataclass
class GuildSettings:
    """Sunucu ayarları modeli"""
    guild_id: int
    prefix: str = "!"
    language: str = "tr"
    welcome_channel: Optional[int] = None
    goodbye_channel: Optional[int] = None
    log_channel: Optional[int] = None
    autorole_enabled: bool = False
    word_filter_enabled: bool = True
    spam_protection_enabled: bool = True
    anti_raid_enabled: bool = True
    welcome_message: Optional[str] = None
    goodbye_message: Optional[str] = None
    created_at: datetime = datetime.now()

@dataclass
class Warning:
    """Uyarı modeli"""
    id: int
    guild_id: int
    user_id: int
    moderator_id: int
    reason: str
    created_at: datetime = datetime.now()

@dataclass
class AutoRole:
    """Otomatik rol modeli"""
    id: int
    guild_id: int
    role_id: int
    trigger_type: str  # 'join', 'reaction', 'level'
    trigger_value: str = ""
    created_at: datetime = datetime.now()

@dataclass
class UserStats:
    """Kullanıcı istatistikleri modeli"""
    guild_id: int
    user_id: int
    message_count: int = 0
    voice_time: int = 0
    last_active: datetime = datetime.now()

@dataclass
class ModLog:
    """Moderasyon kaydı modeli"""
    id: int
    guild_id: int
    user_id: int
    moderator_id: int
    action: str
    reason: str
    duration: Optional[int] = None
    created_at: datetime = datetime.now()

@dataclass
class BannedWord:
    """Yasaklı kelime modeli"""
    id: int
    guild_id: int
    word: str
    severity: int = 1  # 1: Uyarı, 2: Susturma, 3: Atma
    created_at: datetime = datetime.now()

@dataclass
class SpamTracking:
    """Spam takip modeli"""
    guild_id: int
    user_id: int
    message_count: int = 0
    last_message: datetime = datetime.now()

import sqlite3
import aiosqlite
import asyncio
from datetime import datetime, timedelta
import json

class Database:
    def __init__(self, db_path="bot_database.db"):
        self.db_path = db_path
        self.connection = None
    
    async def initialize(self):
        """Veritabanını başlat ve tabloları oluştur"""
        self.connection = await aiosqlite.connect(self.db_path)
        await self.create_tables()
        print("✅ Veritabanı başlatıldı")
    
    async def create_tables(self):
        """Gerekli tabloları oluştur"""
        
        # Sunucu ayarları tablosu
        await self.connection.execute('''
            CREATE TABLE IF NOT EXISTS guild_settings (
                guild_id INTEGER PRIMARY KEY,
                prefix TEXT DEFAULT '!',
                language TEXT DEFAULT 'tr',
                welcome_channel INTEGER,
                goodbye_channel INTEGER,
                log_channel INTEGER,
                autorole_enabled INTEGER DEFAULT 0,
                word_filter_enabled INTEGER DEFAULT 1,
                spam_protection_enabled INTEGER DEFAULT 1,
                anti_raid_enabled INTEGER DEFAULT 1,
                welcome_message TEXT,
                goodbye_message TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Uyarı sistemi tablosu
        await self.connection.execute('''
            CREATE TABLE IF NOT EXISTS warnings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id INTEGER,
                user_id INTEGER,
                moderator_id INTEGER,
                reason TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (guild_id) REFERENCES guild_settings(guild_id)
            )
        ''')
        
        # Otomatik rol tablosu
        await self.connection.execute('''
            CREATE TABLE IF NOT EXISTS auto_roles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id INTEGER,
                role_id INTEGER,
                trigger_type TEXT, -- 'join', 'reaction', 'level'
                trigger_value TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (guild_id) REFERENCES guild_settings(guild_id)
            )
        ''')
        
        # Kullanıcı istatistikleri tablosu
        await self.connection.execute('''
            CREATE TABLE IF NOT EXISTS user_stats (
                guild_id INTEGER,
                user_id INTEGER,
                message_count INTEGER DEFAULT 0,
                voice_time INTEGER DEFAULT 0,
                last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (guild_id, user_id),
                FOREIGN KEY (guild_id) REFERENCES guild_settings(guild_id)
            )
        ''')
        
        # Moderasyon kayıtları tablosu
        await self.connection.execute('''
            CREATE TABLE IF NOT EXISTS mod_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id INTEGER,
                user_id INTEGER,
                moderator_id INTEGER,
                action TEXT,
                reason TEXT,
                duration INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (guild_id) REFERENCES guild_settings(guild_id)
            )
        ''')
        
        # Yasaklı kelimeler tablosu
        await self.connection.execute('''
            CREATE TABLE IF NOT EXISTS banned_words (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id INTEGER,
                word TEXT,
                severity INTEGER DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (guild_id) REFERENCES guild_settings(guild_id)
            )
        ''')
        
        # Spam koruması tablosu
        await self.connection.execute('''
            CREATE TABLE IF NOT EXISTS spam_tracking (
                guild_id INTEGER,
                user_id INTEGER,
                message_count INTEGER DEFAULT 0,
                last_message TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (guild_id, user_id),
                FOREIGN KEY (guild_id) REFERENCES guild_settings(guild_id)
            )
        ''')
        
        await self.connection.commit()
    
    # Sunucu ayarları fonksiyonları
    async def add_guild(self, guild_id):
        """Yeni sunucu ekle"""
        await self.connection.execute(
            'INSERT OR IGNORE INTO guild_settings (guild_id) VALUES (?)',
            (guild_id,)
        )
        await self.connection.commit()
    
    async def get_guild_settings(self, guild_id):
        """Sunucu ayarlarını getir"""
        cursor = await self.connection.execute(
            'SELECT * FROM guild_settings WHERE guild_id = ?',
            (guild_id,)
        )
        result = await cursor.fetchone()
        if result:
            columns = [description[0] for description in cursor.description]
            return dict(zip(columns, result))
        return None
    
    async def update_guild_setting(self, guild_id, setting, value):
        """Sunucu ayarını güncelle"""
        await self.connection.execute(
            f'UPDATE guild_settings SET {setting} = ? WHERE guild_id = ?',
            (value, guild_id)
        )
        await self.connection.commit()
    
    # Uyarı sistemi fonksiyonları
    async def add_warning(self, guild_id, user_id, moderator_id, reason):
        """Kullanıcıya uyarı ekle"""
        await self.connection.execute(
            'INSERT INTO warnings (guild_id, user_id, moderator_id, reason) VALUES (?, ?, ?, ?)',
            (guild_id, user_id, moderator_id, reason)
        )
        await self.connection.commit()
    
    async def get_warnings(self, guild_id, user_id):
        """Kullanıcının uyarılarını getir"""
        cursor = await self.connection.execute(
            'SELECT * FROM warnings WHERE guild_id = ? AND user_id = ? ORDER BY created_at DESC',
            (guild_id, user_id)
        )
        return await cursor.fetchall()
    
    async def remove_warning(self, warning_id):
        """Uyarı sil"""
        await self.connection.execute(
            'DELETE FROM warnings WHERE id = ?',
            (warning_id,)
        )
        await self.connection.commit()
    
    # Otomatik rol fonksiyonları
    async def add_auto_role(self, guild_id, role_id, trigger_type, trigger_value=""):
        """Otomatik rol ekle"""
        await self.connection.execute(
            'INSERT INTO auto_roles (guild_id, role_id, trigger_type, trigger_value) VALUES (?, ?, ?, ?)',
            (guild_id, role_id, trigger_type, trigger_value)
        )
        await self.connection.commit()
    
    async def get_auto_roles(self, guild_id, trigger_type=None):
        """Otomatik rolleri getir"""
        if trigger_type:
            cursor = await self.connection.execute(
                'SELECT * FROM auto_roles WHERE guild_id = ? AND trigger_type = ?',
                (guild_id, trigger_type)
            )
        else:
            cursor = await self.connection.execute(
                'SELECT * FROM auto_roles WHERE guild_id = ?',
                (guild_id,)
            )
        return await cursor.fetchall()
    
    async def remove_auto_role(self, guild_id, role_id):
        """Otomatik rol sil"""
        await self.connection.execute(
            'DELETE FROM auto_roles WHERE guild_id = ? AND role_id = ?',
            (guild_id, role_id)
        )
        await self.connection.commit()
    
    # Moderasyon kayıtları fonksiyonları
    async def add_mod_log(self, guild_id, user_id, moderator_id, action, reason, duration=None):
        """Moderasyon kaydı ekle"""
        await self.connection.execute(
            'INSERT INTO mod_logs (guild_id, user_id, moderator_id, action, reason, duration) VALUES (?, ?, ?, ?, ?, ?)',
            (guild_id, user_id, moderator_id, action, reason, duration)
        )
        await self.connection.commit()
    
    async def get_mod_logs(self, guild_id, user_id=None, limit=50):
        """Moderasyon kayıtlarını getir"""
        if user_id:
            cursor = await self.connection.execute(
                'SELECT * FROM mod_logs WHERE guild_id = ? AND user_id = ? ORDER BY created_at DESC LIMIT ?',
                (guild_id, user_id, limit)
            )
        else:
            cursor = await self.connection.execute(
                'SELECT * FROM mod_logs WHERE guild_id = ? ORDER BY created_at DESC LIMIT ?',
                (guild_id, limit)
            )
        return await cursor.fetchall()
    
    # Yasaklı kelimeler fonksiyonları
    async def add_banned_word(self, guild_id, word, severity=1):
        """Yasaklı kelime ekle"""
        await self.connection.execute(
            'INSERT INTO banned_words (guild_id, word, severity) VALUES (?, ?, ?)',
            (guild_id, word.lower(), severity)
        )
        await self.connection.commit()
    
    async def get_banned_words(self, guild_id):
        """Yasaklı kelimeleri getir"""
        cursor = await self.connection.execute(
            'SELECT word, severity FROM banned_words WHERE guild_id = ?',
            (guild_id,)
        )
        return await cursor.fetchall()
    
    async def remove_banned_word(self, guild_id, word):
        """Yasaklı kelime sil"""
        await self.connection.execute(
            'DELETE FROM banned_words WHERE guild_id = ? AND word = ?',
            (guild_id, word.lower())
        )
        await self.connection.commit()
    
    # Spam koruması fonksiyonları
    async def update_spam_tracking(self, guild_id, user_id):
        """Spam takibini güncelle"""
        now = datetime.now()
        
        # Mevcut kaydı getir
        cursor = await self.connection.execute(
            'SELECT message_count, last_message FROM spam_tracking WHERE guild_id = ? AND user_id = ?',
            (guild_id, user_id)
        )
        result = await cursor.fetchone()
        
        if result:
            count, last_message = result
            last_message = datetime.fromisoformat(last_message)
            
            # Son mesajdan 1 dakika geçmişse sayacı sıfırla
            if now - last_message > timedelta(minutes=1):
                count = 1
            else:
                count += 1
            
            await self.connection.execute(
                'UPDATE spam_tracking SET message_count = ?, last_message = ? WHERE guild_id = ? AND user_id = ?',
                (count, now.isoformat(), guild_id, user_id)
            )
        else:
            count = 1
            await self.connection.execute(
                'INSERT INTO spam_tracking (guild_id, user_id, message_count, last_message) VALUES (?, ?, ?, ?)',
                (guild_id, user_id, count, now.isoformat())
            )
        
        await self.connection.commit()
        return count
    
    # Kullanıcı istatistikleri fonksiyonları
    async def update_user_stats(self, guild_id, user_id, message_count=0, voice_time=0):
        """Kullanıcı istatistiklerini güncelle"""
        await self.connection.execute('''
            INSERT INTO user_stats (guild_id, user_id, message_count, voice_time, last_active)
            VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(guild_id, user_id) DO UPDATE SET
            message_count = message_count + ?,
            voice_time = voice_time + ?,
            last_active = CURRENT_TIMESTAMP
        ''', (guild_id, user_id, message_count, voice_time, message_count, voice_time))
        await self.connection.commit()
    
    async def get_user_stats(self, guild_id, user_id):
        """Kullanıcı istatistiklerini getir"""
        cursor = await self.connection.execute(
            'SELECT * FROM user_stats WHERE guild_id = ? AND user_id = ?',
            (guild_id, user_id)
        )
        result = await cursor.fetchone()
        if result:
            columns = [description[0] for description in cursor.description]
            return dict(zip(columns, result))
        return None
    
    async def close(self):
        """Veritabanı bağlantısını kapat"""
        if self.connection:
            await self.connection.close()
            print("✅ Veritabanı bağlantısı kapatıldı")

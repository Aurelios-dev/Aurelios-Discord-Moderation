# Turkish Moderation Bot

## Overview

This is a comprehensive Turkish Discord moderation bot built with Python and discord.py. The bot provides advanced moderation features, auto-role management, logging capabilities, and spam protection specifically designed for Turkish Discord servers.

## System Architecture

### Core Architecture
- **Language**: Python 3.x
- **Discord Library**: discord.py with application commands (slash commands)
- **Database**: SQLite with aiosqlite for async operations
- **Design Pattern**: Cog-based modular architecture
- **Configuration**: JSON-based configuration management

### Project Structure
```
/
├── bot.py              # Main bot class and initialization
├── main.py             # Entry point and bot startup
├── database.py         # Database management and operations
├── models.py           # Data models and structures
├── config.json         # Bot configuration settings
├── cogs/               # Modular command groups
│   ├── admin.py        # Administrative commands
│   ├── autorole.py     # Automatic role management
│   ├── logging.py      # Event logging system
│   ├── moderation.py   # Moderation commands
│   └── utility.py      # Utility and help commands
└── utils/              # Helper utilities
    ├── filters.py      # Word filtering system
    └── helpers.py      # General helper functions
```

## Key Components

### 1. Bot Core (bot.py)
- **Purpose**: Main bot class inheriting from discord.Bot
- **Features**: 
  - Comprehensive Discord intents configuration
  - Dynamic prefix support
  - Database integration
  - Automatic cog loading
- **Architecture Decision**: Uses discord.py's commands.Bot for structured command handling

### 2. Database Layer (database.py)
- **Technology**: SQLite with aiosqlite for async operations
- **Tables**:
  - `guild_settings`: Server-specific configurations
  - `warnings`: User warning system
  - `auto_roles`: Automatic role assignments
  - `banned_words`: Custom word filtering
  - `user_stats`: User activity tracking
- **Design Choice**: SQLite chosen for simplicity and portability

### 3. Modular Command System (cogs/)
- **Architecture**: Discord.py cog system for organized command groups
- **Benefits**: 
  - Hot-reloading capabilities
  - Isolated functionality
  - Easy maintenance and scaling
- **Command Types**: Both prefix and slash commands supported

### 4. Word Filtering System (utils/filters.py)
- **Features**: 
  - Cached word filtering for performance
  - Severity-based punishment system
  - Regular expression support
- **Performance**: 5-minute cache system to reduce database queries

### 5. Configuration Management (utils/helpers.py)
- **Format**: JSON-based configuration
- **Features**: 
  - Dynamic configuration loading
  - Automatic default config generation
  - Runtime configuration updates

## Data Flow

### 1. Command Processing
```
User Input → Discord Gateway → Bot Event Handler → Cog Command → Database Query → Response
```

### 2. Auto-Moderation Flow
```
Message Event → Word Filter Check → Spam Detection → Action Execution → Logging
```

### 3. Member Events
```
Member Join/Leave → Auto-Role Assignment → Welcome/Goodbye Messages → Event Logging
```

## External Dependencies

### Core Dependencies
- **discord.py**: Discord API wrapper
- **aiosqlite**: Async SQLite operations
- **psutil**: System monitoring for utility commands

### Discord Permissions Required
- **Essential**: Send Messages, Read Message History, Manage Messages
- **Moderation**: Kick Members, Ban Members, Manage Roles, Timeout Members
- **Advanced**: Manage Channels, View Audit Log, Manage Webhooks

### Environment Variables
- `DISCORD_BOT_TOKEN`: Discord bot authentication token

## Deployment Strategy

### Local Development
- SQLite database for easy setup
- Environment variable configuration
- Modular cog system for development flexibility

### Production Considerations
- Bot token security through environment variables
- Database backup strategies
- Error handling and logging
- Rate limit management

### Scalability Options
- Database migration path available (SQLite → PostgreSQL)
- Modular architecture supports feature additions
- Caching system for performance optimization

## User Preferences

Preferred communication style: Simple, everyday language.

## Changelog

Changelog:
- June 28, 2025: Initial setup with comprehensive moderation bot
- June 28, 2025: Fixed `/yardım` command loading issue by resolving duplicate command conflicts

## Technical Notes

### Architecture Decisions

1. **SQLite Database Choice**
   - **Problem**: Need persistent data storage for bot settings and user data
   - **Solution**: SQLite with async operations
   - **Rationale**: Simple setup, no external database server required, good for small to medium servers
   - **Migration Path**: Can be upgraded to PostgreSQL for larger deployments

2. **Cog-based Architecture**
   - **Problem**: Organization of multiple bot features
   - **Solution**: Discord.py cog system
   - **Benefits**: Modular development, hot-reloading, isolated functionality
   - **Trade-off**: Slight complexity increase for better maintainability

3. **Dual Command System**
   - **Problem**: Supporting both legacy and modern Discord command formats
   - **Solution**: Both prefix commands and slash commands
   - **Rationale**: Backward compatibility while embracing modern Discord features

4. **Turkish Language Focus**
   - **Problem**: Most moderation bots are English-focused
   - **Solution**: Turkish-specific features, messages, and configurations
   - **Benefits**: Better user experience for Turkish Discord communities

5. **JSON Configuration**
   - **Problem**: Need flexible bot configuration
   - **Solution**: JSON-based config with runtime updates
   - **Benefits**: Easy to modify, version control friendly, human-readable

### Performance Considerations
- Word filter caching system (5-minute cache)
- Async database operations throughout
- Event-driven architecture for real-time responses
- Efficient permission checking before command execution
import discord
from discord.ext import commands
import asyncio
import os
import json
from database import Database
from utils.helpers import load_config, get_prefix

class TurkishModerationBot(commands.Bot):
    def __init__(self):
        # Bot ayarları
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members = True
        intents.guilds = True
        intents.reactions = True
        intents.voice_states = True
        intents.presences = True
        
        super().__init__(
            command_prefix=get_prefix,
            intents=intents,
            case_insensitive=True,
            help_command=None,
            description="Türkçe Discord Moderasyon Botu"
        )
        
        # Veritabanı bağlantısı
        self.db = Database()
        self.config = load_config()
        
    async def setup_hook(self):
        """Bot başlatıldığında çalışacak kurulum fonksiyonu"""
        print("🔄 Bot başlatılıyor...")
        
        # Veritabanını başlat
        await self.db.initialize()
        
        # Cog'ları yükle
        cogs = [
            'cogs.moderation',
            'cogs.autorole', 
            'cogs.logging',
            'cogs.admin',
            'cogs.utility'
        ]
        
        for cog in cogs:
            try:
                await self.load_extension(cog)
                print(f"✅ {cog} cog'u yüklendi")
            except Exception as e:
                print(f"❌ {cog} cog'u yüklenirken hata: {e}")
        
        # Slash komutları senkronize et
        try:
            synced = await self.tree.sync()
            print(f"✅ {len(synced)} slash komutu senkronize edildi")
        except Exception as e:
            print(f"❌ Slash komutları senkronize edilirken hata: {e}")
    
    async def on_ready(self):
        """Bot hazır olduğunda çalışır"""
        print(f"🤖 {self.user} olarak giriş yapıldı!")
        print(f"📊 {len(self.guilds)} sunucuda aktif")
        print("🎉 Bot hazır!")
        
        # Bot durumunu ayarla
        await self.change_presence(
            activity=discord.Activity(
                type=discord.ActivityType.watching,
                name="Sunucu Güvenliği | /yardım"
            )
        )
    
    async def on_guild_join(self, guild):
        """Yeni sunucuya katıldığında çalışır"""
        print(f"🎉 Yeni sunucuya katıldı: {guild.name} ({guild.id})")
        
        # Sunucu ayarlarını veritabanına ekle
        await self.db.add_guild(guild.id)
        
        # Karşılama mesajı gönder
        if guild.system_channel:
            embed = discord.Embed(
                title="🎉 Merhaba!",
                description="Türkçe Moderasyon Botu'na hoş geldiniz!\n\n"
                           "Başlamak için `/yardım` komutunu kullanabilirsiniz.\n"
                           "Detaylı kurulum için `/kurulum` komutunu kullanın.",
                color=discord.Color.green()
            )
            embed.add_field(
                name="📋 Temel Komutlar",
                value="• `/yardım` - Yardım menüsü\n"
                      "• `/kurulum` - Bot kurulumu\n"
                      "• `/ayarlar` - Sunucu ayarları",
                inline=False
            )
            try:
                await guild.system_channel.send(embed=embed)
            except:
                pass
    
    async def on_guild_remove(self, guild):
        """Sunucudan atıldığında çalışır"""
        print(f"❌ Sunucudan ayrıldı: {guild.name} ({guild.id})")
    
    async def on_command_error(self, ctx, error):
        """Komut hatalarını yakalar"""
        if isinstance(error, commands.CommandNotFound):
            return
        elif isinstance(error, commands.MissingPermissions):
            embed = discord.Embed(
                title="❌ Yetki Hatası",
                description="Bu komutu kullanmak için gerekli yetkilere sahip değilsiniz.",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed, delete_after=10)
        elif isinstance(error, commands.BotMissingPermissions):
            embed = discord.Embed(
                title="❌ Bot Yetki Hatası", 
                description="Bu komutu çalıştırmak için botta gerekli yetkiler bulunmuyor.",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed, delete_after=10)
        elif isinstance(error, commands.MissingRequiredArgument):
            embed = discord.Embed(
                title="❌ Eksik Parametre",
                description=f"Gerekli parametre eksik: `{error.param.name}`",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed, delete_after=10)
        else:
            print(f"Hata: {error}")
            embed = discord.Embed(
                title="❌ Beklenmeyen Hata",
                description="Bir hata oluştu. Lütfen tekrar deneyin.",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed, delete_after=10)
    
    async def close(self):
        """Bot kapanırken çalışır"""
        print("🔄 Bot kapatılıyor...")
        await self.db.close()
        await super().close()
